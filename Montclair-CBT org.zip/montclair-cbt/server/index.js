/**
 * Montclair CBT — shared backend (zero npm dependencies)
 * One database for all devices. Only one admin.
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");

const PORT = process.env.PORT || 3001;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
let DATA_FILE = path.join(DATA_DIR, "db.json");
function resolveDataFile() {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(path.join(DATA_DIR, ".write-test"), "ok");
    fs.unlinkSync(path.join(DATA_DIR, ".write-test"));
    return path.join(DATA_DIR, "db.json");
  } catch (e) {
    const fallback = path.join(require("os").tmpdir(), "montclair-cbt-data");
    if (!fs.existsSync(fallback)) fs.mkdirSync(fallback, { recursive: true });
    console.warn("Using data dir:", fallback);
    return path.join(fallback, "db.json");
  }
}
DATA_FILE = resolveDataFile();
const PUBLIC = path.join(__dirname, "..");

const ADMIN_EMAIL = "montclaircollege001@gmail.com";
const ADMIN_PASSWORD = "Montclair College 1234@$$$";
const SCHOOL_CODE = "MONT2026";

function uid() {
  return "id_" + crypto.randomBytes(6).toString("hex") + Date.now().toString(36);
}
function hash(s) {
  return crypto.createHash("sha256").update(String(s)).digest("hex");
}
function now() {
  return Date.now();
}

function emptyDb() {
  const schoolId = "sch_montclair";
  const userId = "admin_montclair";
  const sessId = "sess_montclair";
  const termId = "term_montclair";
  const year = new Date().getFullYear();
  const d = {
    version: 2,
    schools: [{
      id: schoolId,
      name: "Montclair Group of Schools",
      code: SCHOOL_CODE,
      address: "Oke-Aro & Matogun Campuses, Ogun State",
      phone: "08023367728, 08033902833, 08131809332, 09028087788",
      email: ADMIN_EMAIL,
      logo: "assets/logo.jpeg",
      campuses: [
        { name: "Oke-Aro Campus", address: "Plot 17, 19 & 23 Oduduwa Crescent, Behind Oke-Aro Bus Stop, Oke-Aro, Ogun State" },
        { name: "Matogun Campus", address: "Plot 7, 9, 11 & 13 Alhaji Moshood Ejun Str., Foursquare Bus Stop, Otemuyi, Matogun, Ogun State" }
      ],
      motto: "Knowledge · Power",
      sections: "Nursery, Primary & Secondary",
      createdAt: now()
    }],
    sessions: [{ id: sessId, schoolId, name: year + "/" + (year + 1), isCurrent: true }],
    terms: [{ id: termId, schoolId, sessionId: sessId, name: "1st Term", isCurrent: true }],
    classes: [],
    subjects: [],
    users: [{
      id: userId, schoolId, email: ADMIN_EMAIL, passwordHash: hash(ADMIN_PASSWORD),
      role: "ADMIN", status: "ACTIVE", firstName: "Montclair", lastName: "Admin",
      phone: "08023367728", createdAt: now()
    }],
    students: [], staff: [], parents: [], parentLinks: [],
    assignments: [], questions: [], exams: [], attempts: [], results: [],
    marksheets: [], attendance: [], dailyNotes: [], notices: [], messages: [],
    reportCards: [], activity: [], notifications: [], galleryImages: []
  };
  [
    ["Nursery 1","NURSERY"],["Nursery 2","NURSERY"],
    ["Primary 1","PRIMARY"],["Primary 2","PRIMARY"],["Primary 3","PRIMARY"],
    ["Primary 4","PRIMARY"],["Primary 5","PRIMARY"],["Primary 6","PRIMARY"],
    ["JSS 1","JSS"],["JSS 2","JSS"],["JSS 3","JSS"],
    ["SSS 1","SSS"],["SSS 2","SSS"],["SSS 3","SSS"]
  ].forEach(function (pair) {
    d.classes.push({ id: uid(), schoolId: schoolId, name: pair[0], section: pair[1], isActive: true });
  });
  [
    ["Mathematics","MTH"],["English Language","ENG"],["Basic Science","BSC"],
    ["Civic Education","CIV"],["Social Studies","SOS"],["Computer Studies","ICT"],
    ["Biology","BIO"],["Physics","PHY"],["Chemistry","CHM"],["Agricultural Science","AGR"]
  ].forEach(function (pair) {
    d.subjects.push({ id: uid(), schoolId: schoolId, name: pair[0], code: pair[1], isActive: true });
  });
  d.notices.push({
    id: uid(), schoolId: schoolId, title: "Welcome to Montclair CBT",
    body: "Register with School Code " + SCHOOL_CODE + ". Admin will approve you.",
    by: userId, at: now()
  });
  return d;
}

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}
function loadDb() {
  ensureDir();
  if (!fs.existsSync(DATA_FILE)) {
    var d = emptyDb();
    fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2));
    return d;
  }
  try {
    var d = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    d.users = d.users.filter(function (u) { return u.role !== "ADMIN" || u.email === ADMIN_EMAIL; });
    var admin = d.users.find(function (u) { return u.role === "ADMIN" && u.email === ADMIN_EMAIL; });
    if (!admin) {
      d.users.push({
        id: "admin_montclair", schoolId: d.schools[0].id, email: ADMIN_EMAIL,
        passwordHash: hash(ADMIN_PASSWORD), role: "ADMIN", status: "ACTIVE",
        firstName: "Montclair", lastName: "Admin", phone: "08023367728", createdAt: now()
      });
    } else {
      admin.passwordHash = hash(ADMIN_PASSWORD);
      admin.status = "ACTIVE";
    }
    saveDb(d);
    return d;
  } catch (e) {
    var d2 = emptyDb();
    saveDb(d2);
    return d2;
  }
}
function saveDb(d) {
  ensureDir();
  fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2));
}

var sessions = new Map();
function makeToken() { return crypto.randomBytes(24).toString("hex"); }

function readBody(req) {
  return new Promise(function (resolve, reject) {
    var chunks = [];
    req.on("data", function (c) { chunks.push(c); });
    req.on("end", function () {
      var raw = Buffer.concat(chunks).toString("utf8");
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch (e) { reject(new Error("Invalid JSON")); }
    });
    req.on("error", reject);
  });
}

function send(res, status, data) {
  var body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Session-Token",
    "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS"
  });
  res.end(body);
}

function getToken(req) {
  var h = req.headers.authorization || "";
  if (h.indexOf("Bearer ") === 0) return h.slice(7);
  return req.headers["x-session-token"] || null;
}

function requireAuth(req, res) {
  var token = getToken(req);
  if (!token || !sessions.has(token)) {
    send(res, 401, { error: "Please sign in again" });
    return null;
  }
  var s = sessions.get(token);
  if (s.exp < Date.now()) {
    sessions.delete(token);
    send(res, 401, { error: "Session expired" });
    return null;
  }
  return s;
}

var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".jpeg": "image/jpeg", ".jpg": "image/jpeg", ".png": "image/png",
  ".svg": "image/svg+xml", ".json": "application/json",
  ".csv": "text/csv", ".ico": "image/x-icon", ".webp": "image/webp"
};

function serveStatic(req, res, pathname) {
  var p = pathname === "/" ? "/index.html" : pathname;
  p = decodeURIComponent(p.split("?")[0]);
  var file = path.normalize(path.join(PUBLIC, p));
  if (file.indexOf(PUBLIC) !== 0) {
    res.writeHead(403); return res.end("Forbidden");
  }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return res.end(fs.readFileSync(path.join(PUBLIC, "index.html")));
  }
  var ext = path.extname(file).toLowerCase();
  res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
}

async function handleApi(req, res, pathname) {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Session-Token",
      "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS"
    });
    return res.end();
  }

  if (pathname === "/api/health" && req.method === "GET") {
    return send(res, 200, { ok: true, school: "Montclair Group of Schools" });
  }

  if (pathname === "/api/auth/login" && req.method === "POST") {
    var body = await readBody(req);
    var email = String(body.email || "").toLowerCase().trim().replace(/\s+/g, "");
    var password = String(body.password || "");
    var db = loadDb();
    var u = db.users.find(function (x) {
      return (x.email || "").toLowerCase().replace(/\s+/g, "") === email;
    });
    if (!u || u.passwordHash !== hash(password)) {
      return send(res, 401, { error: "Invalid email or password" });
    }
    if (u.role === "ADMIN" && u.email !== ADMIN_EMAIL) {
      return send(res, 403, { error: "Only the school admin account can use Admin portal" });
    }
    if (u.status === "PENDING") return send(res, 403, { error: "Account pending admin approval. Contact the school." });
    if (u.status !== "ACTIVE") return send(res, 403, { error: "Account not active" });
    var token = makeToken();
    sessions.set(token, {
      userId: u.id, role: u.role, schoolId: u.schoolId, email: u.email,
      firstName: u.firstName, lastName: u.lastName, exp: Date.now() + 7 * 864e5
    });
    db.activity.unshift({ id: uid(), schoolId: u.schoolId, userId: u.id, action: "LOGIN", details: u.role, at: now() });
    saveDb(db);
    return send(res, 200, {
      token: token,
      user: { id: u.id, email: u.email, role: u.role, schoolId: u.schoolId, firstName: u.firstName, lastName: u.lastName, phone: u.phone, passport: u.passport || null }
    });
  }

  if (pathname === "/api/auth/register" && req.method === "POST") {
    var data = await readBody(req);
    var role = data.role;
    if (role === "ADMIN" || ["STUDENT", "STAFF", "PARENT"].indexOf(role) < 0) {
      return send(res, 403, { error: "Only one admin exists. Registration as admin is blocked." });
    }
    var db = loadDb();
    var school = db.schools.find(function (s) {
      return s.code.toUpperCase() === String(data.schoolCode || "").toUpperCase().trim();
    });
    if (!school) return send(res, 400, { error: "Invalid school code" });
    var email = String(data.email || "").toLowerCase().trim();
    if (!email || !data.password || String(data.password).length < 8) {
      return send(res, 400, { error: "Valid email and password (min 8) required" });
    }
    if (db.users.some(function (u) { return u.email.toLowerCase() === email; })) {
      return send(res, 400, { error: "Email already registered" });
    }
    if (!data.passport) return send(res, 400, { error: "Passport photograph is required" });
    if (role === "STUDENT" && !data.classId) return send(res, 400, { error: "Please select your class" });
    if (role === "STUDENT" && !data.dob) return send(res, 400, { error: "Date of birth is required" });
    if (role === "STAFF" && !data.designation) return send(res, 400, { error: "Please select your designation" });

    var id = uid();
    db.users.push({
      id: id, schoolId: school.id, email: email, passwordHash: hash(data.password), role: role, status: "PENDING",
      firstName: String(data.firstName || "").trim(), lastName: String(data.lastName || "").trim(),
      phone: data.phone || null, passport: data.passport, dob: data.dob || null, age: data.age || null,
      gender: data.gender || null, address: data.address || null, bloodGroup: data.bloodGroup || null,
      createdAt: now()
    });
    if (role === "STUDENT") {
      var cl = db.classes.find(function (c) { return c.id === data.classId; });
      db.students.push({
        userId: id, classId: data.classId || null, admissionNumber: null,
        section: cl ? cl.section : null, guardianName: data.guardianName || null, guardianPhone: data.guardianPhone || null
      });
    } else if (role === "STAFF") {
      db.staff.push({
        userId: id, designation: data.designation || "Teacher",
        subjectsTaught: data.subjectsTaught || null, qualification: data.qualification || null, nextOfKin: data.nextOfKin || null
      });
    } else {
      db.parents.push({ userId: id });
    }

    db.users.filter(function (u) { return u.role === "ADMIN" && u.status === "ACTIVE"; }).forEach(function (a) {
      db.notifications.unshift({
        id: uid(), userId: a.id, title: "New registration",
        message: (data.firstName || "") + " (" + role + ") awaits approval", isRead: false, at: now()
      });
    });
    db.activity.unshift({ id: uid(), schoolId: school.id, userId: id, action: "REGISTER_" + role, details: email, at: now() });
    saveDb(db);
    return send(res, 200, { ok: true, message: "Submitted. Wait for school admin approval before signing in." });
  }

  if (pathname === "/api/auth/logout" && req.method === "POST") {
    var token = getToken(req);
    if (token) sessions.delete(token);
    return send(res, 200, { ok: true });
  }

  if (pathname === "/api/state" && req.method === "GET") {
    var s = requireAuth(req, res); if (!s) return;
    var db = loadDb();
    var sid = s.schoolId;
    function strip(u) { var o = Object.assign({}, u); delete o.passwordHash; return o; }
    return send(res, 200, {
      version: db.version,
      schools: db.schools.filter(function (x) { return x.id === sid; }),
      sessions: db.sessions.filter(function (x) { return x.schoolId === sid; }),
      terms: db.terms.filter(function (x) { return x.schoolId === sid; }),
      classes: db.classes.filter(function (x) { return x.schoolId === sid; }),
      subjects: db.subjects.filter(function (x) { return x.schoolId === sid; }),
      users: db.users.filter(function (x) { return x.schoolId === sid; }).map(strip),
      students: db.students.filter(function (st) {
        return db.users.some(function (u) { return u.id === st.userId && u.schoolId === sid; });
      }),
      staff: db.staff.filter(function (st) {
        return db.users.some(function (u) { return u.id === st.userId && u.schoolId === sid; });
      }),
      parents: db.parents.filter(function (st) {
        return db.users.some(function (u) { return u.id === st.userId && u.schoolId === sid; });
      }),
      parentLinks: db.parentLinks.filter(function (x) { return x.schoolId === sid; }),
      assignments: db.assignments.filter(function (x) { return x.schoolId === sid; }),
      questions: db.questions.filter(function (x) { return x.schoolId === sid; }),
      exams: db.exams.filter(function (x) { return x.schoolId === sid; }),
      attempts: db.attempts.filter(function (a) {
        var e = db.exams.find(function (x) { return x.id === a.examId; });
        return e && e.schoolId === sid;
      }),
      results: db.results.filter(function (x) { return x.schoolId === sid; }),
      marksheets: db.marksheets.filter(function (x) { return x.schoolId === sid; }),
      attendance: db.attendance.filter(function (x) { return x.schoolId === sid; }),
      dailyNotes: db.dailyNotes.filter(function (x) { return x.schoolId === sid; }),
      notices: db.notices.filter(function (x) { return x.schoolId === sid; }),
      messages: db.messages.filter(function (x) { return x.schoolId === sid; }),
      reportCards: db.reportCards.filter(function (x) { return x.schoolId === sid; }),
      activity: db.activity.filter(function (x) { return x.schoolId === sid; }).slice(0, 200),
      notifications: s.role === "ADMIN"
        ? db.notifications.filter(function (n) {
            var u = db.users.find(function (x) { return x.id === n.userId; });
            return u && u.schoolId === sid;
          })
        : db.notifications.filter(function (n) { return n.userId === s.userId; }),
      galleryImages: (db.galleryImages || []).filter(function (g) { return g.schoolId === sid; })
    });
  }

  if (pathname === "/api/state" && req.method === "POST") {
    var s = requireAuth(req, res); if (!s) return;
    var body = await readBody(req);
    var db = loadDb();
    var sid = s.schoolId;
    if (s.role === "ADMIN" && Array.isArray(body.users)) {
      body.users.forEach(function (cu) {
        if (cu.role === "ADMIN") return;
        var u = db.users.find(function (x) { return x.id === cu.id && x.schoolId === sid; });
        if (u && cu.status) u.status = cu.status;
      });
    }
    if (Array.isArray(body.students)) {
      body.students.forEach(function (cs) {
        var st = db.students.find(function (x) { return x.userId === cs.userId; });
        if (st) {
          if (cs.classId !== undefined) st.classId = cs.classId;
          if (cs.admissionNumber) st.admissionNumber = cs.admissionNumber;
          if (cs.section) st.section = cs.section;
        }
      });
    }
    // MERGE by id — never wipe a collection just because client sent a partial list
    function mergeById(key, idField) {
      if (!Array.isArray(body[key])) return;
      idField = idField || "id";
      var existing = db[key] || [];
      var byId = {};
      existing.forEach(function (item) {
        if (item.schoolId === sid || key === "attempts") byId[item[idField]] = item;
      });
      body[key].forEach(function (item) {
        var copy = Object.assign({}, item);
        if (key !== "attempts") copy.schoolId = sid;
        byId[copy[idField]] = copy;
      });
      // Keep items from other schools; for this school use merged map
      var others = existing.filter(function (item) {
        if (key === "attempts") return false;
        return item.schoolId !== sid;
      });
      var merged = Object.keys(byId).map(function (k) { return byId[k]; });
      db[key] = others.concat(merged);
    }
    ["exams","results","marksheets","attendance","dailyNotes","notices","messages","reportCards","assignments","parentLinks","galleryImages"].forEach(function (key) {
      mergeById(key, "id");
    });
    // QUESTIONS_APPEND_ONLY: client can add/update questions, never wipe the bank by omitting ids
    if (Array.isArray(body.questions) && body.questions.length) {
      mergeById("questions", "id");
    }
    if (Array.isArray(body.attempts)) {
      mergeById("attempts", "id");
    }
    if (Array.isArray(body.activity)) {
      // activity: append-only style merge by id
      mergeById("activity", "id");
    }
    if (Array.isArray(body.notifications)) {
      var byId = {};
      (db.notifications || []).forEach(function (n) {
        if (n.userId !== s.userId) byId[n.id] = n;
      });
      body.notifications.forEach(function (n) { byId[n.id] = n; });
      db.notifications = Object.keys(byId).map(function (k) { return byId[k]; });
    }
    saveDb(db);
    return send(res, 200, { ok: true });
  }

  var approveMatch = pathname.match(/^\/api\/users\/([^/]+)\/approve$/);
  if (approveMatch && req.method === "POST") {
    var s = requireAuth(req, res); if (!s) return;
    if (s.role !== "ADMIN") return send(res, 403, { error: "Admin only" });
    var db = loadDb();
    var u = db.users.find(function (x) { return x.id === approveMatch[1] && x.schoolId === s.schoolId; });
    if (!u) return send(res, 404, { error: "Not found" });
    if (u.role === "ADMIN") return send(res, 403, { error: "Cannot modify admin" });
    u.status = "ACTIVE";
    if (u.role === "STUDENT") {
      var st = db.students.find(function (x) { return x.userId === u.id; });
      if (st && !st.admissionNumber) {
        st.admissionNumber = SCHOOL_CODE + "/" + new Date().getFullYear() + "/" + String(Math.floor(Math.random() * 9000) + 1000);
      }
    }
    db.notifications.unshift({ id: uid(), userId: u.id, title: "Approved", message: "You can now sign in.", isRead: false, at: now() });
    db.activity.unshift({ id: uid(), schoolId: s.schoolId, userId: s.userId, action: "APPROVE", details: u.email, at: now() });
    saveDb(db);
    return send(res, 200, { ok: true });
  }

  if (pathname === "/api/questions/bulk" && req.method === "POST") {
    var s = requireAuth(req, res); if (!s) return;
    if (["ADMIN", "STAFF"].indexOf(s.role) < 0) return send(res, 403, { error: "Not allowed" });
    var body = await readBody(req);
    var rows = body.rows || [];
    var subjectId = body.subjectId;
    var classId = body.classId;
    var db = loadDb();
    var n = 0;
    rows.forEach(function (row) {
      var text = String(row.question || row.Question || row.QUESTION || "").trim();
      if (!text) return;
      var options = [
        row.optionA || row.A || row.a || row["Option A"],
        row.optionB || row.B || row.b || row["Option B"],
        row.optionC || row.C || row.c || row["Option C"],
        row.optionD || row.D || row.d || row["Option D"]
      ].map(function (x) { return String(x || "").trim(); }).filter(Boolean);
      var correct = String(row.correct || row.answer || row.Correct || row.Answer || "").trim();
      if (["A","B","C","D"].indexOf(correct.toUpperCase()) >= 0 && options.length) {
        var idx = correct.toUpperCase().charCodeAt(0) - 65;
        if (options[idx]) correct = options[idx];
      }
      if (!options.length || !correct) return;
      db.questions.push({
        id: uid(), schoolId: s.schoolId, createdBy: s.userId, text: text,
        subjectId: subjectId || null, classId: classId || null, type: "MULTIPLE_CHOICE",
        options: options, correctAnswer: correct, marks: parseFloat(row.marks || row.Marks || 1) || 1, createdAt: now()
      });
      n++;
    });
    saveDb(db);
    return send(res, 200, { count: n });
  }

  send(res, 404, { error: "Not found" });
}

var server = http.createServer(async function (req, res) {
  try {
    var u = new URL(req.url || "/", "http://localhost");
    var pathname = u.pathname;
    if (pathname.indexOf("/api/") === 0) {
      await handleApi(req, res, pathname);
    } else {
      serveStatic(req, res, pathname);
    }
  } catch (e) {
    console.error(e);
    if (!res.headersSent) send(res, 500, { error: e.message || "Server error" });
  }
});

loadDb();
server.listen(PORT, function () {
  console.log("Montclair CBT running on port " + PORT);
  console.log("Admin: " + ADMIN_EMAIL);
});
