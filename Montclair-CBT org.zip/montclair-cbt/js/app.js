/* Montclair CBT — Montclair Group of Schools
   Fixed admin · Student/Staff portals · Gallery · CA · Attendance · Report sheets */
(function () {
  "use strict";

  const DB_KEY = "montclair_cbt_v1";
  const SESSION_KEY = "montclair_session_v1";
  const LOCK_KEY = "montclair_lock_v1";
  const MAX_FAILS = 5;
  const LOCK_MS = 5 * 60 * 1000;

  /* ---- Shared backend (so Admin on any phone sees all signups) ---- */
  const API_BASE = (function () {
    if (typeof window !== "undefined" && window.MONTCLAIR_API) return window.MONTCLAIR_API.replace(/\/$/, "");
    // Same origin when served by Node server
    return "";
  })();
  let authToken = null;
  let useServer = false;

  async function apiFetch(path, opts) {
    const headers = Object.assign({ "Content-Type": "application/json" }, (opts && opts.headers) || {});
    if (authToken) headers["Authorization"] = "Bearer " + authToken;
    const res = await fetch(API_BASE + path, Object.assign({}, opts, { headers }));
    let data = null;
    try { data = await res.json(); } catch (e) { data = {}; }
    if (!res.ok) {
      const err = new Error((data && data.error) || ("Request failed " + res.status));
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  async function probeServer() {
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 2500);
      const res = await fetch(API_BASE + "/api/health", { signal: ctrl.signal });
      clearTimeout(t);
      if (res.ok) { useServer = true; return true; }
    } catch (e) { useServer = false; }
    return false;
  }

  function mergeArrayById(localArr, remoteArr) {
    const map = {};
    (localArr || []).forEach(function (item) { if (item && item.id) map[item.id] = item; });
    (remoteArr || []).forEach(function (item) { if (item && item.id) map[item.id] = item; });
    return Object.keys(map).map(function (k) { return map[k]; });
  }

  async function pullState() {
    if (!useServer || !authToken) return;
    const state = await apiFetch("/api/state");
    if (!state || state.error) return;
    const protect = ["questions","exams","results","marksheets","galleryImages","reportCards","users","students","staff","parents","parentLinks","notices","classes","subjects","assignments","attendance","dailyNotes"];
    Object.keys(state).forEach(function (k) {
      if (protect.indexOf(k) >= 0 && Array.isArray(state[k])) {
        db[k] = mergeArrayById(db[k], state[k]);
      } else if (Array.isArray(state[k]) || (state[k] && typeof state[k] === "object")) {
        db[k] = state[k];
      }
    });
    if (!Array.isArray(db.questions)) db.questions = [];
    saveDBLocal();
  }

  async function pushState() {
    if (!useServer || !authToken) return;
    try {
      var payload = Object.assign({}, db);
      if (!payload.questions || !payload.questions.length) delete payload.questions;
      await apiFetch("/api/state", { method: "POST", body: JSON.stringify(payload) });
    } catch (e) {
      console.warn("pushState failed", e.message);
    }
  }

  function saveDBLocal() {
    try { localStorage.setItem(DB_KEY, JSON.stringify(db)); } catch (e) {}
  }



  /* WAEC-style grades */
  function waecGrade(score) {
    if (score >= 75) return "A1";
    if (score >= 70) return "B2";
    if (score >= 65) return "B3";
    if (score >= 60) return "C4";
    if (score >= 55) return "C5";
    if (score >= 50) return "C6";
    if (score >= 45) return "D7";
    if (score >= 40) return "E8";
    return "F9";
  }

  let db, session, route = "landing", ui = {};
  let timerHandle = null;

  function uid() { return "id_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36); }
  function now() { return Date.now(); }
  function hash(s) {
    let h = 0;
    for (let i = 0; i < String(s).length; i++) h = ((h << 5) - h) + s.charCodeAt(i) | 0;
    return "h" + Math.abs(h).toString(16) + "_" + String(s).length;
  }
  
  function parseCSV(text) {
    const lines = String(text).replace(/^\uFEFF/, "").split(/\r?\n/).filter(l => l.trim().length);
    if (lines.length < 2) return [];
    function splitLine(line) {
      const out = []; let cur = ""; let q = false;
      for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === '"') { q = !q; continue; }
        if (c === "," && !q) { out.push(cur.trim()); cur = ""; continue; }
        cur += c;
      }
      out.push(cur.trim());
      return out;
    }
    const headers = splitLine(lines[0]).map(h => h.trim());
    const rows = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = splitLine(lines[i]);
      if (!cols.some(c => c)) continue;
      const obj = {};
      headers.forEach((h, idx) => { obj[h] = cols[idx] != null ? cols[idx] : ""; });
      rows.push(obj);
    }
    return rows;
  }

  async function ensureXLSX() {
    if (typeof XLSX !== "undefined") return true;
    return new Promise((resolve) => {
      const s = document.createElement("script");
      s.src = "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";
      s.onload = () => resolve(typeof XLSX !== "undefined");
      s.onerror = () => resolve(false);
      document.head.appendChild(s);
      setTimeout(() => resolve(typeof XLSX !== "undefined"), 8000);
    });
  }


  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function shuffle(a) {
    const x = [...a];
    for (let i = x.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [x[i], x[j]] = [x[j], x[i]];
    }
    return x;
  }
  function genCode() {
    const c = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let s = "";
    for (let i = 0; i < 8; i++) s += c[Math.floor(Math.random() * c.length)];
    return s;
  }

  function loadDB() {
    try { return JSON.parse(localStorage.getItem(DB_KEY)); } catch (e) { return null; }
  }
  let _pushTimer = null;
  function saveDB() {
    saveDBLocal();
    if (useServer && authToken) {
      if (_pushTimer) clearTimeout(_pushTimer);
      _pushTimer = setTimeout(function () { pushState(); }, 400);
    }
  }
  function initDB() {
    let d = loadDB();
    if (d && d.version >= 1 && d.schools && d.schools.length) {
      if (!Array.isArray(d.galleryImages)) d.galleryImages = [];
      if (!Array.isArray(d.notifications)) d.notifications = [];
      ensureMontclairAdmin(d);
      return d;
    }
    d = seedMontclair();
    localStorage.setItem(DB_KEY, JSON.stringify(d));
    return d;
  }

  function ensureMontclairAdmin(d) {
    const email = "montclaircollege001@gmail.com";
    const pass = "Montclair College 1234@$$$";
    let admin = d.users.find(u => u.role === "ADMIN");
    if (!admin) {
      const schoolId = d.schools[0]?.id || "sch_montclair";
      admin = {
        id: "admin_montclair", schoolId, email, passwordHash: hash(pass),
        role: "ADMIN", status: "ACTIVE", firstName: "Montclair", lastName: "Admin",
        phone: "08023367728", createdAt: now()
      };
      d.users.push(admin);
    } else {
      admin.email = email;
      admin.passwordHash = hash(pass);
      admin.status = "ACTIVE";
      admin.role = "ADMIN";
    }
    saveDB();
  }

  function seedMontclair() {
    const schoolId = "sch_montclair";
    const userId = "admin_montclair";
    const sessId = "sess_montclair";
    const termId = "term_montclair";
    const year = new Date().getFullYear();
    const d = {
      version: 1,
      schools: [{
        id: schoolId,
        name: "Montclair Group of Schools",
        code: "MONT2026",
        address: "Oke-Aro & Matogun Campuses, Ogun State",
        phone: "08023367728, 08033902833, 08131809332, 09028087788",
        email: "montclaircollege001@gmail.com",
        logo: "assets/logo.jpeg",
        campuses: [
          {
            name: "Oke-Aro Campus",
            address: "Plot 17, 19 & 23 Oduduwa Crescent, Behind Oke-Aro Bus Stop, Oke-Aro, Ogun State"
          },
          {
            name: "Matogun Campus",
            address: "Plot 7, 9, 11 & 13 Alhaji Moshood Ejun Str., Foursquare Bus Stop, Otemuyi, Matogun, Ogun State"
          }
        ],
        motto: "Knowledge · Power",
        sections: "Nursery, Primary & Secondary",
        createdAt: Date.now()
      }],
      sessions: [{ id: sessId, schoolId, name: year + "/" + (year + 1), isCurrent: true }],
      terms: [{ id: termId, schoolId, sessionId: sessId, name: "1st Term", isCurrent: true }],
      classes: [],
      subjects: [],
      users: [{
        id: userId, schoolId, email: "montclaircollege001@gmail.com",
        passwordHash: hash("Montclair College 1234@$$$"),
        role: "ADMIN", status: "ACTIVE",
        firstName: "Montclair", lastName: "Admin",
        phone: "08023367728", createdAt: Date.now()
      }],
      students: [], staff: [], parents: [], parentLinks: [],
      assignments: [], questions: [], exams: [], attempts: [], results: [],
      marksheets: [], attendance: [], dailyNotes: [], notices: [], messages: [],
      reportCards: [], activity: [], notifications: [], galleryImages: []
    };
    const classDefs = [
      ["Nursery 1", "NURSERY"], ["Nursery 2", "NURSERY"],
      ["Primary 1", "PRIMARY"], ["Primary 2", "PRIMARY"], ["Primary 3", "PRIMARY"],
      ["Primary 4", "PRIMARY"], ["Primary 5", "PRIMARY"], ["Primary 6", "PRIMARY"],
      ["JSS 1", "JSS"], ["JSS 2", "JSS"], ["JSS 3", "JSS"],
      ["SSS 1", "SSS"], ["SSS 2", "SSS"], ["SSS 3", "SSS"]
    ];
    classDefs.forEach(([name, section]) => {
      d.classes.push({ id: uid(), schoolId, name, section, isActive: true });
    });
    [
      ["Mathematics", "MTH"], ["English Language", "ENG"], ["Basic Science", "BSC"],
      ["Civic Education", "CIV"], ["Social Studies", "SOS"], ["Computer Studies", "ICT"],
      ["Biology", "BIO"], ["Physics", "PHY"], ["Chemistry", "CHM"], ["Agricultural Science", "AGR"]
    ].forEach(([name, codeS]) => {
      d.subjects.push({ id: uid(), schoolId, name, code: codeS, isActive: true });
    });
    d.notices.push({
      id: uid(), schoolId, title: "Welcome to Montclair CBT Portal",
      body: "Students, staff and parents: register with School Code MONT2026. Admin will approve your account before you can sign in.",
      by: userId, at: Date.now()
    });
    return d;
  }

  function setSession(u, token) {
    session = u ? {
      id: u.id, email: u.email, role: u.role, schoolId: u.schoolId,
      firstName: u.firstName, lastName: u.lastName, phone: u.phone || null
    } : null;
    if (session) {
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
      if (token) { authToken = token; sessionStorage.setItem(SESSION_KEY + "_token", token); }
    } else {
      sessionStorage.removeItem(SESSION_KEY);
      sessionStorage.removeItem(SESSION_KEY + "_token");
      authToken = null;
    }
  }
  function restoreSession() {
    try {
      session = JSON.parse(sessionStorage.getItem(SESSION_KEY) || "null");
      authToken = sessionStorage.getItem(SESSION_KEY + "_token") || null;
    } catch (e) { session = null; authToken = null; }
  }

  function toast(msg, type) {
    const box = document.getElementById("toast-box");
    const el = document.createElement("div");
    el.className = "toast " + (type || "info");
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => el.remove(), 3600);
  }

  function logActivity(schoolId, userId, action, details) {
    db.activity.unshift({ id: uid(), schoolId, userId, action, details: details || "", at: now() });
    if (db.activity.length > 400) db.activity.length = 400;
    saveDB();
  }
  function notify(userId, title, message) {
    db.notifications.unshift({ id: uid(), userId, title, message, isRead: false, at: now() });
    saveDB();
  }

  function schoolOf(id) { return db.schools.find(s => s.id === id); }
  function userOf(id) { return db.users.find(u => u.id === id); }
  function classOf(id) { return db.classes.find(c => c.id === id); }
  function subjectOf(id) { return db.subjects.find(s => s.id === id); }
  function currentSession(schoolId) { return db.sessions.find(s => s.schoolId === schoolId && s.isCurrent); }
  function currentTerm(schoolId) { return db.terms.find(t => t.schoolId === schoolId && t.isCurrent); }

  function parentChildren() {
    if (!session || session.role !== "PARENT") return [];
    const links = db.parentLinks.filter(l => l.parentUserId === session.id);
    return links.map(l => {
      const st = db.students.find(s => s.userId === l.studentUserId);
      const u = userOf(l.studentUserId);
      return { user: u, student: st, class: st ? classOf(st.classId) : null };
    }).filter(x => x.user);
  }

  /* ---- API ---- */
  const api = {
    registerSchool(data) {
      if (db.users.some(u => u.email.toLowerCase() === data.email.toLowerCase()))
        return { error: "Email already registered" };
      if (!data.schoolName || !data.address) return { error: "School name and address required" };
      if (!data.password || data.password.length < 8) return { error: "Password min 8 characters" };

      let code = genCode();
      while (db.schools.some(s => s.code === code)) code = genCode();
      const schoolId = uid(), userId = uid(), sessId = uid(), termId = uid();
      const year = new Date().getFullYear();

      db.schools.push({
        id: schoolId, name: data.schoolName.trim(), code, address: data.address.trim(),
        phone: data.phone || null, email: data.schoolEmail || data.email,
        logo: data.logo || null, createdAt: now()
      });
      db.sessions.push({ id: sessId, schoolId, name: year + "/" + (year + 1), isCurrent: true });
      db.terms.push({ id: termId, schoolId, sessionId: sessId, name: "1st Term", isCurrent: true });

      const classDefs = [
        ["Nursery 1", "NURSERY"], ["Nursery 2", "NURSERY"],
        ["Primary 1", "PRIMARY"], ["Primary 2", "PRIMARY"], ["Primary 3", "PRIMARY"],
        ["Primary 4", "PRIMARY"], ["Primary 5", "PRIMARY"], ["Primary 6", "PRIMARY"],
        ["JSS 1", "JSS"], ["JSS 2", "JSS"], ["JSS 3", "JSS"],
        ["SSS 1", "SSS"], ["SSS 2", "SSS"], ["SSS 3", "SSS"]
      ];
      classDefs.forEach(([name, section]) => {
        db.classes.push({ id: uid(), schoolId, name, section, isActive: true });
      });
      [
        ["Mathematics", "MTH"], ["English Language", "ENG"], ["Basic Science", "BSC"],
        ["Civic Education", "CIV"], ["Social Studies", "SOS"], ["Computer Studies", "ICT"],
        ["Biology", "BIO"], ["Physics", "PHY"], ["Chemistry", "CHM"], ["Agricultural Science", "AGR"]
      ].forEach(([name, codeS]) => {
        db.subjects.push({ id: uid(), schoolId, name, code: codeS, isActive: true });
      });

      db.users.push({
        id: userId, schoolId, email: data.email.toLowerCase().trim(),
        passwordHash: hash(data.password), role: "ADMIN", status: "ACTIVE",
        firstName: data.firstName.trim(), lastName: data.lastName.trim(),
        phone: data.phone || null, createdAt: now()
      });
      logActivity(schoolId, userId, "SCHOOL_REGISTER", data.schoolName);
      saveDB();
      return { ok: true, schoolCode: code };
    },

    async registerUser(data) {
      if (data.role === "ADMIN") return { error: "Only one admin exists. Registration as admin is blocked." };
      if (useServer) {
        try {
          const dataRes = await apiFetch("/api/auth/register", {
            method: "POST",
            body: JSON.stringify(data)
          });
          return { ok: true, message: dataRes.message || "Submitted. Wait for school admin approval before signing in." };
        } catch (e) {
          return { error: e.message || "Registration failed" };
        }
      }
      const school = db.schools.find(s => s.code.toUpperCase() === (data.schoolCode || "").toUpperCase().trim());
      if (!school) return { error: "Invalid school code" };
      if (!["STUDENT", "STAFF", "PARENT"].includes(data.role)) return { error: "Invalid role. Admin access is restricted." };
      if (db.users.some(u => u.email.toLowerCase() === data.email.toLowerCase()))
        return { error: "Email already registered" };
      if (!data.password || data.password.length < 8) return { error: "Password min 8 characters" };
      if (!data.passport) return { error: "Passport photograph is required" };
      if (data.role === "STUDENT" && !data.classId) return { error: "Please select your class" };
      if (data.role === "STUDENT" && !data.dob) return { error: "Date of birth is required" };
      if (data.role === "PARENT" && !data.relation) return { error: "Select relationship to student" };
      if (data.role === "STAFF" && !data.designation) return { error: "Please select your designation" };

      const id = uid();
      db.users.push({
        id, schoolId: school.id, email: data.email.toLowerCase().trim(),
        passwordHash: hash(data.password), role: data.role, status: "PENDING",
        firstName: data.firstName.trim(), lastName: data.lastName.trim(),
        phone: data.phone || null, passport: data.passport,
        dob: data.dob || null, age: data.age || null, gender: data.gender || null,
        address: data.address || null, bloodGroup: data.bloodGroup || null,
        createdAt: now()
      });
      if (data.role === "STUDENT") {
        const cl = db.classes.find(c => c.id === data.classId);
        db.students.push({
          userId: id,
          classId: data.classId || null,
          admissionNumber: null,
          section: cl ? cl.section : null,
          guardianName: data.guardianName || null,
          guardianPhone: data.guardianPhone || null
        });
      } else if (data.role === "STAFF") {
        db.staff.push({
          userId: id,
          designation: data.designation || "Teacher",
          subjectsTaught: data.subjectsTaught || null,
          qualification: data.qualification || null,
          nextOfKin: data.nextOfKin || null
        });
      } else {
        db.parents.push({ userId: id });
      }
      db.users.filter(u => u.schoolId === school.id && u.role === "ADMIN" && u.status === "ACTIVE")
        .forEach(a => notify(a.id, "New registration", data.firstName + " (" + data.role + ") awaits approval"));
      logActivity(school.id, id, "REGISTER_" + data.role, data.email);
      saveDB();
      return { ok: true, message: "Submitted. Wait for school admin approval before signing in." };
    },

    async login(email, password) {
      if (useServer) {
        try {
          const data = await apiFetch("/api/auth/login", {
            method: "POST",
            body: JSON.stringify({ email, password })
          });
          setSession(data.user, data.token);
          await pullState();
          return { user: session };
        } catch (e) {
          return { error: e.message || "Login failed" };
        }
      }
      const lockRaw = localStorage.getItem(LOCK_KEY);
      if (lockRaw) {
        try {
          const lock = JSON.parse(lockRaw);
          if (lock.until && Date.now() < lock.until) {
            return { error: "Too many failed attempts. Try again in a few minutes." };
          }
        } catch (e) {}
      }
      const norm = (email || "").toLowerCase().trim().replace(/\s+/g, "");
      const u = db.users.find(x => (x.email || "").toLowerCase().replace(/\s+/g, "") === norm);
      if (!u || u.passwordHash !== hash(password)) {
        let fails = 0;
        try { fails = (JSON.parse(localStorage.getItem(LOCK_KEY) || "{}").fails) || 0; } catch (e) {}
        fails++;
        if (fails >= MAX_FAILS) {
          localStorage.setItem(LOCK_KEY, JSON.stringify({ fails, until: Date.now() + LOCK_MS }));
          return { error: "Temporarily locked. Wait 5 minutes." };
        }
        localStorage.setItem(LOCK_KEY, JSON.stringify({ fails }));
        return { error: "Invalid email or password (" + (MAX_FAILS - fails) + " tries left)" };
      }
      localStorage.removeItem(LOCK_KEY);
      if (u.role === "ADMIN" && u.email !== "montclaircollege001@gmail.com") {
        return { error: "Only the school admin account can use Admin portal" };
      }
      if (u.status === "PENDING") return { error: "Account pending admin approval. Contact your school." };
      if (u.status !== "ACTIVE") return { error: "Account not active" };
      setSession(u);
      logActivity(u.schoolId, u.id, "LOGIN", u.role);
      saveDB();
      return { user: session };
    },

    async logout() {
      try {
        if (useServer && authToken) {
          await apiFetch("/api/auth/logout", { method: "POST", body: "{}" });
        }
      } catch (e) { /* ignore */ }
      if (session) {
        try { logActivity(session.schoolId, session.id, "LOGOUT", ""); } catch (e) {}
      }
      setSession(null);
      authToken = null;
      try {
        sessionStorage.removeItem(SESSION_KEY);
        sessionStorage.removeItem(SESSION_KEY + "_token");
      } catch (e) {}
    },

    async approveUser(userId) {
      if (useServer) {
        try {
          await apiFetch("/api/users/" + userId + "/approve", { method: "POST", body: "{}" });
          await pullState();
          return { ok: true };
        } catch (e) { return { error: e.message }; }
      }
      const u = userOf(userId);
      if (!u || u.schoolId !== session.schoolId) return { error: "Not found" };
      u.status = "ACTIVE";
      if (u.role === "STUDENT") {
        const st = db.students.find(s => s.userId === userId);
        if (st && !st.admissionNumber) {
          const sch = schoolOf(session.schoolId);
          st.admissionNumber = (sch?.code || "MONT") + "/" + new Date().getFullYear() + "/" + String(Math.floor(Math.random() * 9000) + 1000);
        }
      }
      notify(u.id, "Approved", "You can now sign in with your email and password.");
      logActivity(session.schoolId, session.id, "APPROVE", u.email);
      saveDB();
      return { ok: true };
    },

    setStudentClass(userId, classId) {
      const st = db.students.find(s => s.userId === userId);
      if (!st) return { error: "Student not found" };
      const cl = classOf(classId);
      st.classId = classId || null;
      st.section = cl ? cl.section : null;
      if (!st.admissionNumber) {
        const sch = schoolOf(session.schoolId);
        st.admissionNumber = (sch?.code || "SCH") + "/" + new Date().getFullYear() + "/" + String(Math.floor(Math.random() * 9000) + 1000);
      }
      saveDB();
      return { ok: true };
    },

    linkParentChild(parentUserId, studentUserId) {
      if (db.parentLinks.some(l => l.parentUserId === parentUserId && l.studentUserId === studentUserId))
        return { error: "Already linked" };
      db.parentLinks.push({ id: uid(), parentUserId, studentUserId, schoolId: session.schoolId });
      notify(parentUserId, "Child linked", "A student account was linked to your parent portal.");
      saveDB();
      return { ok: true };
    },

    assignStaff(userId, classId, subjectId) {
      if (db.assignments.some(a => a.userId === userId && a.classId === classId && a.subjectId === subjectId))
        return { error: "Already assigned" };
      db.assignments.push({ id: uid(), userId, classId, subjectId, schoolId: session.schoolId });
      notify(userId, "New assignment", (subjectOf(subjectId)?.name || "") + " — " + (classOf(classId)?.name || ""));
      saveDB();
      return { ok: true };
    },

    saveMarks(payload) {
      /* Staff submits CA for admin approval; Admin saves as approved */
      const sess = currentSession(session.schoolId);
      const term = currentTerm(session.schoolId);
      const asAdmin = session.role === "ADMIN";
      const status = asAdmin ? "APPROVED" : "PENDING";
      payload.rows.forEach(r => {
        const ca1 = parseFloat(r.ca1) || 0;
        const ca2 = parseFloat(r.ca2) || 0;
        const cbt = db.results.filter(x =>
          x.userId === r.studentUserId && x.subjectId === payload.subjectId
        ).sort((a, b) => (b.at || 0) - (a.at || 0))[0];
        const exam = cbt
          ? Math.round(((cbt.percentage || 0) / 100) * 60 * 10) / 10
          : (parseFloat(r.exam) || 0);
        const total = ca1 + ca2 + exam;
        const existing = db.marksheets.find(m =>
          m.studentUserId === r.studentUserId && m.subjectId === payload.subjectId &&
          m.sessionName === (sess?.name || "") && m.termName === (term?.name || "")
        );
        const row = {
          studentUserId: r.studentUserId, subjectId: payload.subjectId, classId: payload.classId,
          schoolId: session.schoolId,
          sessionName: sess?.name || "", termName: term?.name || "",
          ca1, ca2, exam, total, grade: waecGrade(total), updatedAt: now(),
          examFromCbt: !!cbt,
          status,
          enteredBy: session.id,
          approvedBy: asAdmin ? session.id : null,
          approvedAt: asAdmin ? now() : null
        };
        if (existing) Object.assign(existing, row);
        else db.marksheets.push({ id: uid(), ...row });
      });
      if (!asAdmin) {
        // Notify admin
        const admins = db.users.filter(u => u.schoolId === session.schoolId && u.role === "ADMIN");
        admins.forEach(a => notify(a.id, "CA marks pending approval",
          session.firstName + " submitted CA for " + (subjectOf(payload.subjectId)?.name || "a subject")));
      }
      logActivity(session.schoolId, session.id, asAdmin ? "SAVE_MARKS" : "SUBMIT_CA", payload.subjectId);
      saveDB();
      return { ok: true, status };
    },

    approveMarks(markIds) {
      if (session.role !== "ADMIN") return { error: "Only admin can approve CA" };
      let n = 0;
      (markIds || []).forEach(id => {
        const m = db.marksheets.find(x => x.id === id);
        if (m && m.schoolId === session.schoolId) {
          m.status = "APPROVED";
          m.approvedBy = session.id;
          m.approvedAt = now();
          n++;
        }
      });
      // or approve all pending for school
      if (!markIds || !markIds.length) {
        db.marksheets.forEach(m => {
          if (m.schoolId === session.schoolId && m.status === "PENDING") {
            m.status = "APPROVED";
            m.approvedBy = session.id;
            m.approvedAt = now();
            n++;
          }
        });
      }
      logActivity(session.schoolId, session.id, "APPROVE_CA", n + " rows");
      saveDB();
      return { count: n };
    },

    setSchoolStamp(dataUrl) {
      if (session.role !== "ADMIN") return { error: "Admin only" };
      const sch = schoolOf(session.schoolId);
      if (!sch) return { error: "School not found" };
      sch.stamp = dataUrl;
      saveDB();
      return { ok: true };
    },

    setSchoolSignature(dataUrl) {
      if (session.role !== "ADMIN") return { error: "Admin only" };
      const sch = schoolOf(session.schoolId);
      if (!sch) return { error: "School not found" };
      sch.signature = dataUrl;
      saveDB();
      return { ok: true };
    },

    saveAttendance(classId, dateStr, records) {
      /* records: [{studentUserId, status: PRESENT|ABSENT|LATE}] */
      records.forEach(r => {
        const existing = db.attendance.find(a =>
          a.studentUserId === r.studentUserId && a.classId === classId && a.date === dateStr
        );
        if (existing) existing.status = r.status;
        else db.attendance.push({
          id: uid(), schoolId: session.schoolId, classId, studentUserId: r.studentUserId,
          date: dateStr, status: r.status, by: session.id, at: now()
        });
      });
      logActivity(session.schoolId, session.id, "ATTENDANCE", classId + " " + dateStr);
      saveDB();
      return { ok: true };
    },

    saveDailyNote(studentUserId, note) {
      const today = new Date().toISOString().slice(0, 10);
      db.dailyNotes.unshift({
        id: uid(), schoolId: session.schoolId, studentUserId, date: today,
        meal: note.meal || "", nap: note.nap || "", activity: note.activity || "",
        mood: note.mood || "", teacherNote: note.teacherNote || "", by: session.id, at: now()
      });
      const links = db.parentLinks.filter(l => l.studentUserId === studentUserId);
      links.forEach(l => notify(l.parentUserId, "Daily nursery note", "New daily report for your child"));
      saveDB();
      return { ok: true };
    },

    createQuestion(q) {
      const id = uid();
      db.questions.push({ id, schoolId: session.schoolId, createdBy: session.id, ...q, createdAt: now() });
      saveDB();
      return { id };
    },

    deleteQuestion(id) {
      const q = db.questions.find(x => x.id === id);
      if (!q || q.schoolId !== session.schoolId) return { error: "Not found" };
      if (session.role !== "ADMIN" && session.role !== "STAFF") return { error: "Not allowed" };
      db.questions = db.questions.filter(x => x.id !== id);
      db.exams.forEach(e => {
        if (e.questionIds) e.questionIds = e.questionIds.filter(qid => qid !== id);
      });
      saveDB();
      return { ok: true };
    },

    async bulkQuestions(rows, subjectId, classId) {
      var count = 0;
      var sid = session.schoolId;
      (rows || []).forEach(function (row) {
        var text = (row.question || row.Question || row.QUESTION || row["question text"] || "").toString().trim();
        if (!text) return;
        var opts = [
          row.optionA || row.OptionA || row.A || row["Option A"] || "",
          row.optionB || row.OptionB || row.B || row["Option B"] || "",
          row.optionC || row.OptionC || row.C || row["Option C"] || "",
          row.optionD || row.OptionD || row.D || row["Option D"] || ""
        ].map(function (o) { return String(o).trim(); }).filter(Boolean);
        var correct = (row.correct || row.Correct || row.answer || "").toString().trim();
        var letter = correct.toUpperCase();
        if (["A","B","C","D"].indexOf(letter) >= 0 && opts[letter.charCodeAt(0) - 65]) {
          correct = opts[letter.charCodeAt(0) - 65];
        }
        var marks = parseFloat(row.marks || row.Marks || 1) || 1;
        db.questions.push({
          id: uid(),
          schoolId: sid,
          createdBy: session.id,
          subjectId: subjectId || null,
          classId: classId || null,
          text: text,
          options: opts.length ? opts : ["Option A", "Option B", "Option C", "Option D"],
          correctAnswer: correct,
          marks: marks,
          createdAt: now()
        });
        count++;
      });
      saveDBLocal();
      if (useServer) {
        try {
          await apiFetch("/api/questions/bulk", {
            method: "POST",
            body: JSON.stringify({ rows: rows, subjectId: subjectId, classId: classId })
          });
          await pullState();
          saveDBLocal();
        } catch (e) {
          console.warn("bulk server sync", e.message);
        }
      } else {
        saveDB();
      }
      return { count: count };
    },


    createExam(data) {
      const id = uid();
      db.exams.push({
        id, schoolId: session.schoolId, createdBy: session.id, status: "DRAFT",
        publishedAt: null, ...data, createdAt: now()
      });
      saveDB();
      return { id };
    },

    publishExam(examId) {
      const e = db.exams.find(x => x.id === examId);
      if (!e || e.schoolId !== session.schoolId) return { error: "Not found" };
      e.status = "PUBLISHED";
      e.publishedAt = now();
      saveDB();
      return { ok: true };
    },

    startAttempt(examId) {
      const exam = db.exams.find(e => e.id === examId);
      if (!exam || exam.status !== "PUBLISHED") return { error: "Exam not available" };
      const t = now();
      const student = db.students.find(s => s.userId === session.id);
      if (!student) return { error: "Student profile missing" };
      if (exam.classId && student.classId !== exam.classId) return { error: "Not for your class" };

      let attempt = db.attempts.find(a => a.examId === examId && a.userId === session.id);
      if (attempt) {
        if (attempt.status === "SUBMITTED" || attempt.status === "AUTO_SUBMITTED")
          return { error: "Already submitted" };
        if (attempt.status === "IN_PROGRESS" && attempt.endsAt <= t) {
          api._submit(attempt.id, true);
          return { error: "Time expired — previous attempt auto-submitted" };
        }
        if (attempt.status === "IN_PROGRESS")
          return { attempt, questions: api._qs(exam) };
      }
      const endsAt = t + (exam.durationMinutes || 30) * 60 * 1000;
      attempt = {
        id: uid(), examId, userId: session.id, status: "IN_PROGRESS",
        startedAt: t, endsAt, answers: {}
      };
      db.attempts.push(attempt);
      logActivity(session.schoolId, session.id, "START_EXAM", exam.title);
      saveDB();
      return { attempt, questions: api._qs(exam) };
    },

    _qs(exam) {
      let qs = (exam.questionIds || []).map(qid => {
        const q = db.questions.find(x => x.id === qid);
        if (!q) return null;
        let options = [...(q.options || [])];
        if (exam.randomizeOptions) options = shuffle(options);
        return { id: q.id, text: q.text, options, marks: q.marks || 1 };
      }).filter(Boolean);
      if (exam.randomizeQuestions) qs = shuffle(qs);
      return qs;
    },

    saveAnswer(attemptId, qid, answer) {
      const a = db.attempts.find(x => x.id === attemptId);
      if (!a || a.userId !== session.id || a.status !== "IN_PROGRESS") return { error: "Closed" };
      if (a.endsAt <= now()) { api._submit(attemptId, true); return { error: "Time up" }; }
      a.answers[qid] = answer;
      saveDB();
      return { ok: true };
    },

    submitAttempt(attemptId, auto) { return api._submit(attemptId, !!auto); },

    _submit(attemptId, auto) {
      const a = db.attempts.find(x => x.id === attemptId);
      if (!a || a.status !== "IN_PROGRESS") return { error: "Invalid" };
      const exam = db.exams.find(e => e.id === a.examId);
      let correct = 0, wrong = 0, unanswered = 0, raw = 0, max = 0;
      (exam.questionIds || []).forEach(qid => {
        const q = db.questions.find(x => x.id === qid);
        if (!q) return;
        const m = q.marks || 1;
        max += m;
        const sel = a.answers[qid];
        if (sel == null || sel === "") { unanswered++; return; }
        if (String(sel) === String(q.correctAnswer)) { correct++; raw += m; }
        else wrong++;
      });
      const pct = max > 0 ? (raw / max) * 100 : 0;
      a.status = auto ? "AUTO_SUBMITTED" : "SUBMITTED";
      a.submittedAt = now();
      a.score = raw; a.maxScore = max; a.percentage = pct;

      const existing = db.results.find(r => r.examId === a.examId && r.userId === a.userId);
      const result = {
        id: existing ? existing.id : uid(),
        schoolId: exam.schoolId, examId: a.examId, userId: a.userId,
        classId: exam.classId, subjectId: exam.subjectId,
        totalQuestions: (exam.questionIds || []).length,
        correct, wrong, unanswered, rawScore: raw, maxScore: max,
        percentage: pct, grade: waecGrade(pct), status: "MARKED",
        publishedAt: null, attemptId: a.id, at: now()
      };
      if (existing) Object.assign(existing, result);
      else db.results.push(result);
      notify(a.userId, "CBT submitted", exam.title);
      logActivity(exam.schoolId, a.userId, auto ? "AUTO_SUBMIT" : "SUBMIT", exam.title);
      saveDB();
      return { ok: true, result };
    },

    publishResult(id) {
      const r = db.results.find(x => x.id === id);
      if (!r || r.schoolId !== session.schoolId) return { error: "Not found" };
      r.status = "PUBLISHED";
      r.publishedAt = now();
      notify(r.userId, "Result published", "Your CBT result is available");
      saveDB();
      return { ok: true };
    },

    generateReport(studentUserId) {
      const st = db.students.find(s => s.userId === studentUserId);
      const u = userOf(studentUserId);
      if (!st || !u) return { error: "Student not found" };
      const sess = currentSession(session.schoolId);
      const term = currentTerm(session.schoolId);
      const sessionName = sess?.name || "";
      const termName = term?.name || "";

      // Manual CA only (what admin/teacher types)
      // Prefer admin-approved CA; fall back to any if admin generates
      let caRows = db.marksheets.filter(m =>
        m.studentUserId === studentUserId &&
        m.sessionName === sessionName && m.termName === termName &&
        (m.status === "APPROVED" || !m.status)
      );
      if (!caRows.length) {
        caRows = db.marksheets.filter(m =>
          m.studentUserId === studentUserId &&
          m.sessionName === sessionName && m.termName === termName
        );
      }

      // CBT results → automatic EXAM score (out of 60)
      const cbtResults = db.results.filter(r =>
        r.userId === studentUserId && r.schoolId === session.schoolId &&
        (r.status === "PUBLISHED" || r.status === "MARKED")
      );
      const cbtBySubject = {};
      cbtResults.forEach(r => {
        const key = r.subjectId || ("exam_" + r.examId);
        if (!cbtBySubject[key] || (r.at || 0) > (cbtBySubject[key].at || 0)) {
          cbtBySubject[key] = r;
        }
      });

      const subjectIds = new Set();
      caRows.forEach(m => { if (m.subjectId) subjectIds.add(m.subjectId); });
      Object.keys(cbtBySubject).forEach(k => {
        const r = cbtBySubject[k];
        if (r.subjectId) subjectIds.add(r.subjectId);
      });

      if (!subjectIds.size && !Object.keys(cbtBySubject).length) {
        return { error: "No CA marks or CBT results for this student yet." };
      }

      const subjects = [];
      // Subjects with CA and/or CBT linked by subjectId
      subjectIds.forEach(subjectId => {
        const ca = caRows.find(m => m.subjectId === subjectId);
        const cbt = Object.keys(cbtBySubject).map(k => cbtBySubject[k]).find(r => r.subjectId === subjectId);
        const ca1 = ca ? (parseFloat(ca.ca1) || 0) : 0;
        const ca2 = ca ? (parseFloat(ca.ca2) || 0) : 0;
        // Exam from CBT only (out of 60). Never require admin to type exam.
        let exam = 0;
        let examTitle = "";
        let gradeCbt = null;
        if (cbt) {
          exam = Math.round(((cbt.percentage || 0) / 100) * 60 * 10) / 10;
          const ex = db.exams.find(e => e.id === cbt.examId);
          examTitle = ex?.title || "";
          gradeCbt = cbt.grade;
        } else if (ca && ca.exam && !cbt) {
          // fallback only if old data had typed exam and no CBT
          exam = parseFloat(ca.exam) || 0;
        }
        const total = Math.round((ca1 + ca2 + exam) * 10) / 10;
        subjects.push({
          subjectId,
          subject: subjectOf(subjectId)?.name || "—",
          ca1, ca2, exam, total,
          grade: waecGrade(total),
          source: cbt ? "CA+CBT" : "CA",
          examTitle,
          cbtPercent: cbt ? cbt.percentage : null
        });
      });

      // CBT subjects with no CA row yet — still show exam-only line
      Object.keys(cbtBySubject).forEach(k => {
        const r = cbtBySubject[k];
        if (r.subjectId && subjects.some(s => s.subjectId === r.subjectId)) return;
        if (r.subjectId) return; // already handled
        const exam = Math.round(((r.percentage || 0) / 100) * 60 * 10) / 10;
        const ex = db.exams.find(e => e.id === r.examId);
        const total = exam; // no CA
        subjects.push({
          subjectId: r.subjectId || null,
          subject: subjectOf(r.subjectId)?.name || (ex?.title || "CBT Exam"),
          ca1: 0, ca2: 0, exam, total,
          grade: waecGrade(total),
          source: "CBT",
          examTitle: ex?.title || "",
          cbtPercent: r.percentage
        });
      });

      if (!subjects.length) return { error: "Nothing to put on the report card yet." };

      const avg = subjects.reduce((s, x) => s + x.total, 0) / subjects.length;
      const rc = {
        id: uid(), schoolId: session.schoolId, userId: studentUserId, classId: st.classId,
        sessionName, termName, status: "GENERATED",
        subjects, average: avg, overallGrade: waecGrade(avg),
        teacherRemark: "CA entered by teacher. Exam score from CBT.",
        principalRemark: "", createdAt: now(), publishedAt: null, source: "CA_PLUS_CBT"
      };
      db.reportCards = db.reportCards.filter(x =>
        !(x.userId === studentUserId && x.sessionName === sessionName && x.termName === termName)
      );
      db.reportCards.push(rc);
      saveDB();
      return { id: rc.id };
    },

    /** Generate report cards for every student who has CBT results */
    generateReportsFromCBT(classId) {
      const students = db.students.filter(s => {
        const u = userOf(s.userId);
        return u && u.schoolId === session.schoolId && u.status === "ACTIVE" &&
          (!classId || s.classId === classId);
      });
      let n = 0, errors = [];
      students.forEach(st => {
        const has = db.results.some(r => r.userId === st.userId && r.schoolId === session.schoolId);
        if (!has) return;
        const res = this.generateReport(st.userId);
        if (res.id) n++;
        else if (res.error) errors.push(res.error);
      });
      return { count: n, errors };
    },

    publishReport(id) {
      const rc = db.reportCards.find(x => x.id === id);
      if (!rc) return { error: "Not found" };
      rc.status = "PUBLISHED";
      rc.publishedAt = now();
      notify(rc.userId, "Report card ready", "Your termly report sheet is published");
      const links = db.parentLinks.filter(l => l.studentUserId === rc.userId);
      links.forEach(l => notify(l.parentUserId, "Report card", "Child report card published"));
      saveDB();
      return { ok: true };
    },

    postNotice(title, body) {
      db.notices.unshift({
        id: uid(), schoolId: session.schoolId, title, body, by: session.id, at: now()
      });
      saveDB();
      return { ok: true };
    },

    sendMessage(toUserId, body) {
      db.messages.unshift({
        id: uid(), schoolId: session.schoolId, from: session.id, to: toUserId,
        body, isRead: false, at: now()
      });
      notify(toUserId, "New message", body.slice(0, 60));
      saveDB();
      return { ok: true };
    }
  };

  /* ---- Router ---- */
  function go(r, data) {
    if (timerHandle) clearInterval(timerHandle);
    route = r;
    ui = data || {};
    render();
    window.scrollTo(0, 0);
  }

  function render() {
    db = loadDB() || db;
    const root = document.getElementById("app");
    if (!session) {
      if (route === "login") root.innerHTML = viewLogin();
      else if (route === "register") root.innerHTML = viewRegister();
      else if (route === "admin-register") root.innerHTML = viewLogin(); // admin is fixed
      else root.innerHTML = viewLanding();
      bind();
      return;
    }
    if (session.role === "ADMIN") root.innerHTML = shell("ADMIN", viewAdmin());
    else if (session.role === "STAFF") root.innerHTML = shell("STAFF", viewStaff());
    else if (session.role === "PARENT") root.innerHTML = shell("PARENT", viewParent());
    else root.innerHTML = shell("STUDENT", viewStudent());
    bind();
  }

  function shell(role, body) {
    const school = schoolOf(session.schoolId);
    const term = currentTerm(session.schoolId);
    const sess = currentSession(session.schoolId);
    const navMap = {
      ADMIN: [
        ["dashboard", "Dashboard"], ["users", "Users"], ["classes", "Classes"],
        ["subjects", "Subjects"], ["questions", "Questions"], ["exams", "CBT Exams"],
        ["marks", "CA & Marks"], ["results", "Results"], ["reports", "Report Sheets"],
        ["notices", "Notices"], ["gallery", "Gallery"], ["notifications", "Notifications"], ["activity", "Activity"]
      ],
      STAFF: [
        ["dashboard", "Dashboard"], ["marks", "CA Entry"], ["attendance", "Attendance"],
        ["questions", "Questions"], ["exams", "CBT Exams"], ["results", "Results"],
        ["nursery", "Nursery Notes"], ["notices", "Notices"], ["gallery", "Gallery"], ["notifications", "Notifications"]
      ],
      STUDENT: [
        ["dashboard", "Home"], ["exams", "CBT"], ["results", "Results"],
        ["reports", "Report Card"], ["gallery", "Gallery"], ["notifications", "Notifications"], ["notices", "Notices"]
      ],
      PARENT: [
        ["dashboard", "Home"], ["results", "Results"], ["reports", "Report Cards"],
        ["gallery", "Gallery"], ["notifications", "Notifications"], ["notices", "Notices"], ["nursery", "Daily Notes"]
      ]
    };
    const nav = navMap[role] || navMap.STUDENT;
    const current = ui.page || "dashboard";
    const navHtml = nav.map(([k, l]) =>
      `<div class="nav-item ${current === k ? "active" : ""}" data-page="${k}">${l}</div>`
    ).join("");

    const bottomItems = role === "ADMIN"
      ? [["dashboard", "🏠", "Home"], ["users", "👥", "Users"], ["questions", "❓", "Questions"], ["exams", "📝", "Exams"], ["marks", "📊", "Marks"]]
      : role === "STAFF"
      ? [["dashboard", "🏠", "Home"], ["questions", "❓", "Questions"], ["exams", "📝", "Exams"], ["marks", "📊", "CA"], ["attendance", "✅", "Attend"]]
      : role === "PARENT"
      ? [["dashboard", "🏠", "Home"], ["results", "📊", "Results"], ["reports", "📄", "Reports"], ["nursery", "🧒", "Daily"], ["notices", "📢", "News"]]
      : [["dashboard", "🏠", "Home"], ["exams", "📝", "CBT"], ["results", "📊", "Results"], ["reports", "📄", "Report"], ["notices", "📢", "News"]];

    const bottom = `<nav class="bottom-nav">${bottomItems.map(([k, ico, lab]) =>
      `<button data-page="${k}" class="${current === k ? "active" : ""}">${ico}<span>${lab}</span></button>`
    ).join("")}</nav>`;

    const unread = db.notifications.filter(n => n.userId === session.id && !n.isRead).length;

    return `
    <div class="overlay" id="overlay"></div>
    <div class="app">
      <aside class="sidebar" id="sidebar">
        <div class="sidebar-head">
          <div style="display:flex;gap:10px;align-items:center">
            ${school?.logo ? `<img src="${school.logo}" style="width:44px;height:44px;border-radius:12px;object-fit:cover">` : `<div class="logo-mark">🎓</div>`}
            <div style="min-width:0">
              <div style="font-weight:700;font-size:13px;line-height:1.3">${escapeHtml(school?.name || "School")}</div>
              <div style="font-size:11px;color:var(--muted)">${role}${school?.code ? " · " + escapeHtml(school.code) : ""}</div>
            </div>
          </div>
          ${school?.address ? `<div style="font-size:11px;color:var(--muted);margin-top:8px;line-height:1.4">📍 ${escapeHtml(school.address)}</div>` : ""}
        </div>
        <div class="sidebar-nav">${navHtml}</div>
        <div class="sidebar-foot">
          <div style="font-size:13px;font-weight:600;margin-bottom:8px">${escapeHtml(session.firstName)} ${escapeHtml(session.lastName)}</div>
          <button class="btn btn-outline btn-sm btn-block" id="btn-logout">Sign out</button>
        </div>
      </aside>
      <div class="main">
        <header class="topbar">
          <button class="btn btn-secondary btn-sm no-print" id="btn-menu" style="display:none">☰</button>
          <div style="font-weight:600;font-size:14px;flex:1">${nav.find(n => n[0] === current)?.[1] || "Dashboard"}</div>
          <span class="term-pill">${escapeHtml(sess?.name || "")} · ${escapeHtml(term?.name || "")}</span>
          <div class="notif-bell no-print" id="notif-bell">🔔${unread ? '<span class="notif-dot"></span>' : ""}</div>
          <button type="button" class="btn btn-outline btn-sm no-print" id="btn-logout-top" style="height:36px;padding:0 12px">Sign out</button>
        </header>
        <div class="content">${body}</div>
      </div>
    </div>${bottom}`;
  }

  /* ---- Views ---- */
  function viewLanding() {
    return `
    <div class="landing">
      <header class="landing-header">
        <div class="logo">
          <img src="assets/logo.jpeg" alt="Montclair" style="width:44px;height:44px;border-radius:10px;object-fit:contain;background:#fff">
          <span>Montclair CBT</span>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-outline btn-sm" data-go="login">Sign in</button>
          <button class="btn btn-primary btn-sm" data-go="register">Join school</button>
        </div>
      </header>
      <div class="hero">
        <img src="assets/banner.jpeg" alt="Montclair Group of Schools" class="brand-banner" style="max-width:520px;margin:0 auto 16px;display:block">
        <h1>Montclair <span>CBT Portal</span></h1>
        <p>Nursery · Primary · Secondary — Oke-Aro &amp; Matogun Campuses, Ogun State. Computer-based tests, continuous assessment, attendance and report sheets.</p>
        <div class="hero-actions">
          <button class="btn btn-primary btn-lg" data-go="login">Staff / Student / Parent / Admin Sign in</button>
          <button class="btn btn-outline btn-lg" data-go="register">Join with School Code</button>
        </div>
      </div>
      <div class="portal-cards" style="grid-template-columns:repeat(3,1fr)">
        <div class="portal-card" data-go="login">
          <div class="ico">🛡️</div><h3>Admin</h3>
          <p>School management, approvals, publish results (authorised account only)</p>
        </div>
        <div class="portal-card" data-go="register" data-role="STAFF">
          <div class="ico">👩‍🏫</div><h3>Staff</h3>
          <p>Join with code <strong>MONT2026</strong> · CA, attendance, CBT</p>
        </div>
        <div class="portal-card" data-go="register" data-role="STUDENT">
          <div class="ico">👨‍🎓</div><h3>Student</h3>
          <p>Join with code <strong>MONT2026</strong> · Take CBT exams</p>
        </div>
        <div class="portal-card" data-go="register" data-role="PARENT">
          <div class="ico">👨‍👩‍👧</div><h3>Parent</h3>
          <p>Join with code <strong>MONT2026</strong> · View child results</p>
        </div>
      </div>
      <div style="max-width:900px;margin:0 auto 40px;padding:0 16px">
        <h3 style="text-align:center;margin-bottom:12px;color:#1a237e">Our Campuses</h3>
        <div class="campus-card">
          <h4>Oke-Aro Campus</h4>
          <p style="font-size:13px;color:var(--muted)">Plot 17, 19 &amp; 23 Oduduwa Crescent, Behind Oke-Aro Bus Stop, Oke-Aro, Ogun State</p>
        </div>
        <div class="campus-card">
          <h4>Matogun Campus</h4>
          <p style="font-size:13px;color:var(--muted)">Plot 7, 9, 11 &amp; 13 Alhaji Moshood Ejun Str., Foursquare Bus Stop, Otemuyi, Matogun, Ogun State</p>
        </div>
        <p style="text-align:center;font-size:13px;color:var(--muted);margin-top:8px">Tel: 08023367728 · 08033902833 · 08131809332 · 09028087788</p>
      </div>
    </div>`;
  }

  function viewLogin() {
    return `
    <div class="auth-wrap"><div class="auth-box">
      <div style="text-align:center;margin-bottom:16px">
        <div class="logo-mark" style="margin:0 auto 10px">🎓</div>
        <h2 style="font-size:22px">Sign in</h2>
        <p style="color:var(--muted);font-size:13px">Montclair CBT — email and password</p>
      </div>
      <div class="card">
        <div class="field"><label class="label">Email</label><input class="input" id="login-email" type="email"></div>
        <div class="field"><label class="label">Password</label><input class="input" id="login-pass" type="password"></div>
        <button class="btn btn-primary btn-lg btn-block" id="btn-login">Sign in</button>
        <p style="text-align:center;margin-top:14px;font-size:13px;color:var(--muted)">
          <a href="#" data-go="register" style="color:var(--green);font-weight:600">Join a school</a> ·
          <a href="#" data-go="admin-register" style="color:var(--green);font-weight:600">Register school</a>
        </p>
      </div>
      <p style="text-align:center;margin-top:12px;font-size:12px"><a href="#" data-go="landing">← Home</a></p>
    </div></div>`;
  }

  function viewRegister() {
    const role = ui.role || "STUDENT";
    const school = (db.schools && db.schools[0]) || null;
    const classes = (db.classes || []).filter(c => !school || c.schoolId === school.id);
    const passPreview = ui.regPassport
      ? `<img class="passport-preview" id="reg-pass-preview" src="${ui.regPassport}" alt="Passport">`
      : `<div class="passport-preview empty" id="reg-pass-preview">📷</div>`;

    const studentFields = role === "STUDENT" ? `
        <div class="reg-section">
          <h4>3. Student information</h4>
          <div class="field"><label class="label">Class *</label>
            <select class="select" id="reg-class">
              <option value="">Select class…</option>
              ${classes.map(c => `<option value="${c.id}">${escapeHtml(c.name)}${c.section ? " (" + escapeHtml(c.section) + ")" : ""}</option>`).join("")}
            </select>
          </div>
          <div class="grid-2">
            <div class="field"><label class="label">Date of birth *</label>
              <input class="input" id="reg-dob" type="date" max="${new Date().toISOString().slice(0,10)}"></div>
            <div class="field"><label class="label">Age</label>
              <input class="input" id="reg-age" type="number" min="2" max="25" placeholder="Auto from DOB" readonly style="background:#f1f3f5"></div>
          </div>
          <div class="grid-2">
            <div class="field"><label class="label">Gender</label>
              <select class="select" id="reg-gender">
                <option value="">Select…</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div class="field"><label class="label">Blood group</label>
              <select class="select" id="reg-blood">
                <option value="">Optional</option>
                <option>A+</option><option>A-</option><option>B+</option><option>B-</option>
                <option>AB+</option><option>AB-</option><option>O+</option><option>O-</option>
              </select>
            </div>
          </div>
          <div class="field"><label class="label">Home address</label>
            <textarea class="input" id="reg-address" rows="2" placeholder="House address, area, town"></textarea></div>
          <div class="field"><label class="label">Parent / Guardian name</label>
            <input class="input" id="reg-guardian" placeholder="Full name of parent or guardian"></div>
          <div class="field"><label class="label">Parent / Guardian phone</label>
            <input class="input" id="reg-guardian-phone" type="tel" placeholder="080…"></div>
        </div>` : "";

    const staffFields = role === "STAFF" ? `
        <div class="reg-section">
          <h4>3. Staff information</h4>
          <div class="field"><label class="label">Designation / Role *</label>
            <select class="select" id="reg-des">
              <option value="">Select…</option>
              <option>Class Teacher</option>
              <option>Subject Teacher</option>
              <option>Head of Department</option>
              <option>Vice Principal</option>
              <option>Principal</option>
              <option>Admin Officer</option>
              <option>Other</option>
            </select>
          </div>
          <div class="field"><label class="label">Subjects you teach (optional)</label>
            <input class="input" id="reg-subjects" placeholder="e.g. Mathematics, Basic Science"></div>
          <div class="grid-2">
            <div class="field"><label class="label">Date of birth</label>
              <input class="input" id="reg-dob" type="date" max="${new Date().toISOString().slice(0,10)}"></div>
            <div class="field"><label class="label">Gender</label>
              <select class="select" id="reg-gender">
                <option value="">Select…</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
          </div>
          <div class="field"><label class="label">Qualification</label>
            <input class="input" id="reg-qualification" placeholder="e.g. B.Ed, NCE, B.Sc"></div>
          <div class="field"><label class="label">Home address</label>
            <textarea class="input" id="reg-address" rows="2" placeholder="Residential address"></textarea></div>
          <div class="field"><label class="label">Next of kin name &amp; phone</label>
            <input class="input" id="reg-nok" placeholder="Name — phone number"></div>
        </div>` : "";

    const parentFields = role === "PARENT" ? `
        <div class="reg-section">
          <h4>3. Parent information</h4>
          <div class="field"><label class="label">Relationship to student *</label>
            <select class="select" id="reg-relation">
              <option value="">Select…</option>
              <option>Father</option>
              <option>Mother</option>
              <option>Guardian</option>
              <option>Other</option>
            </select>
          </div>
          <div class="field"><label class="label">Occupation (optional)</label>
            <input class="input" id="reg-occupation" placeholder="e.g. Trader, Civil servant"></div>
          <div class="field"><label class="label">Home address</label>
            <textarea class="input" id="reg-address" rows="2" placeholder="House address"></textarea></div>
          <p class="hint">After admin approves you, the school will link your account to your child's student profile.</p>
        </div>` : "";



    return `
    <div class="auth-wrap"><div class="auth-box wide">
      <div style="text-align:center;margin-bottom:14px">
        <img src="assets/logo.jpeg" alt="" style="width:52px;height:52px;border-radius:12px;margin:0 auto 10px;object-fit:contain;background:#fff">
        <h2 style="font-size:20px">Join Montclair</h2>
        <p style="color:var(--muted);font-size:13px">Complete all sections · Admin must approve you</p>
      </div>
      <div class="card">
        <div class="auth-tabs" style="grid-template-columns:1fr 1fr">
          <div class="auth-tab ${role === "STUDENT" ? "active" : ""}" data-set-role="STUDENT">Student</div>
          <div class="auth-tab ${role === "STAFF" ? "active" : ""}" data-set-role="STAFF">Staff</div>
          <div class="auth-tab ${role === "PARENT" ? "active" : ""}" data-set-role="PARENT">Parent</div>
        </div>

        <div class="reg-section">
          <h4>1. School access</h4>
          <div class="field"><label class="label">School Code *</label>
            <input class="input" id="reg-code" value="MONT2026" style="text-transform:uppercase;font-weight:700;letter-spacing:.08em"></div>
        </div>

        <div class="reg-section">
          <h4>2. Account details</h4>
          <div class="grid-2">
            <div class="field"><label class="label">First name *</label><input class="input" id="reg-fn" autocomplete="given-name"></div>
            <div class="field"><label class="label">Last name *</label><input class="input" id="reg-ln" autocomplete="family-name"></div>
          </div>
          <div class="field"><label class="label">Email *</label><input class="input" id="reg-email" type="email" autocomplete="email"></div>
          <div class="field"><label class="label">Phone *</label><input class="input" id="reg-phone" type="tel" placeholder="080…"></div>
          <div class="field"><label class="label">Password *</label><input class="input" id="reg-pass" type="password" placeholder="Min 8 characters" autocomplete="new-password"></div>
        </div>

        ${studentFields}
        ${staffFields}
        ${parentFields}

        <div class="reg-section">
          <h4>4. Passport photograph *</h4>
          <div class="passport-row" style="align-items:center">
            <div id="reg-pass-wrap" style="cursor:pointer" title="Add passport">
              ${passPreview}
            </div>
            <div style="flex:1;min-width:140px">
              <label class="label">Passport photo *</label>
              <span style="font-size:13px;color:var(--muted);display:block;margin-bottom:8px">Tap photo or a button below</span>
              <div style="display:flex;flex-wrap:wrap;gap:8px">
                <button type="button" class="btn btn-primary btn-sm" id="btn-pass-camera">📷 Take picture</button>
                <button type="button" class="btn btn-outline btn-sm" id="btn-pass-gallery">🖼 Gallery</button>
                <button type="button" class="btn btn-outline btn-sm" id="btn-pass-file">📁 Upload file</button>
              </div>
              <!-- hidden inputs: camera uses capture, gallery/file do not -->
              <input type="file" id="reg-passport-camera" accept="image/*" capture="user" style="display:none">
              <input type="file" id="reg-passport-gallery" accept="image/*" style="display:none">
              <input type="file" id="reg-passport-file" accept="image/jpeg,image/png,image/webp,image/*" style="display:none">
            </div>
          </div>
          <div id="pass-sheet" class="hidden" style="position:fixed;inset:0;z-index:200;background:rgba(0,0,0,.45);display:flex;align-items:flex-end;justify-content:center">
            <div style="background:#fff;width:100%;max-width:420px;border-radius:16px 16px 0 0;padding:20px 16px 28px;box-shadow:0 -8px 30px rgba(0,0,0,.15)">
              <div style="width:40px;height:4px;background:#ddd;border-radius:4px;margin:0 auto 16px"></div>
              <p style="font-weight:700;text-align:center;margin-bottom:14px">Add passport photo</p>
              <button type="button" class="btn btn-primary btn-block" id="sheet-camera" style="margin-bottom:8px">📷 Take picture</button>
              <button type="button" class="btn btn-outline btn-block" id="sheet-gallery" style="margin-bottom:8px">🖼 Choose from gallery</button>
              <button type="button" class="btn btn-outline btn-block" id="sheet-file" style="margin-bottom:8px">📁 Upload from files</button>
              <button type="button" class="btn btn-secondary btn-block" id="sheet-cancel">Cancel</button>
            </div>
          </div>
        </div>

        <button class="btn btn-primary btn-lg btn-block" id="btn-register">Submit for approval</button>
        <p style="text-align:center;margin-top:14px;font-size:13px">
          <a href="#" data-go="login" style="color:var(--green);font-weight:600">Already registered? Sign in</a>
        </p>
      </div>
      <p style="text-align:center;margin-top:12px;font-size:12px"><a href="#" data-go="landing">← Home</a></p>
    </div></div>`;
  }

function viewAdminRegister() {
    const step = ui.step || 1;
    if (ui.doneCode) {
      return `
      <div class="auth-wrap"><div class="auth-box">
        <div class="card" style="text-align:center;padding:28px">
          <div style="font-size:40px;margin-bottom:8px">✅</div>
          <h2>School registered</h2>
          <p style="color:var(--muted);margin:10px 0">Staff & students join with School Code:</p>
          <div style="font-size:26px;font-weight:800;letter-spacing:.1em;color:var(--green);padding:14px;background:var(--green-soft);border-radius:12px">${escapeHtml(ui.doneCode)}</div>
          <button class="btn btn-primary btn-block" style="margin-top:18px" data-go="login">Go to sign in</button>
        </div>
      </div></div>`;
    }
    return `
    <div class="auth-wrap"><div class="auth-box wide">
      <div style="text-align:center;margin-bottom:12px">
        <div class="logo-mark" style="margin:0 auto 8px">🛡️</div>
        <h2 style="font-size:20px">Register your school</h2>
      </div>
      <div class="card">
        <div class="step-bar">
          <div class="step-dot ${step >= 1 ? "on" : ""}"></div>
          <div class="step-dot ${step >= 2 ? "on" : ""}"></div>
        </div>
        ${step === 1 ? `
        <h3 style="font-size:15px;margin-bottom:12px">1. School details</h3>
        <div class="field"><label class="label">School name *</label><input class="input" id="ar-school" value="${escapeHtml(ui.schoolName || "")}"></div>
        <div class="field"><label class="label">Address *</label><textarea class="input" id="ar-address" rows="2">${escapeHtml(ui.address || "")}</textarea></div>
        <div class="grid-2">
          <div class="field"><label class="label">Phone</label><input class="input" id="ar-phone" value="${escapeHtml(ui.phone || "")}"></div>
          <div class="field"><label class="label">School email</label><input class="input" id="ar-semail" type="email" value="${escapeHtml(ui.schoolEmail || "")}"></div>
        </div>
        <div class="field"><label class="label">Logo (optional)</label>
          <label class="file-drop"><input type="file" id="ar-logo" accept="image/*"><span style="font-size:13px;color:var(--muted)">Upload logo</span></label>
        </div>
        <button class="btn btn-primary btn-block" id="ar-next1">Continue</button>
        ` : `
        <h3 style="font-size:15px;margin-bottom:12px">2. Admin account</h3>
        <div class="grid-2">
          <div class="field"><label class="label">First name *</label><input class="input" id="ar-fn"></div>
          <div class="field"><label class="label">Last name *</label><input class="input" id="ar-ln"></div>
        </div>
        <div class="field"><label class="label">Admin email *</label><input class="input" id="ar-email" type="email"></div>
        <div class="field"><label class="label">Password *</label><input class="input" id="ar-pass" type="password" placeholder="Min 8 characters"></div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-secondary" id="ar-back2">Back</button>
          <button class="btn btn-primary" style="flex:1" id="ar-submit">Complete</button>
        </div>
        `}
      </div>
      <p style="text-align:center;margin-top:12px;font-size:12px"><a href="#" data-go="landing">← Home</a></p>
    </div></div>`;
  }

  function viewAdmin() {
    const page = ui.page || "dashboard";
    const sid = session.schoolId;
    if (page === "users") return pageUsers();
    if (page === "classes") return pageSimpleList("Classes", db.classes.filter(c => c.schoolId === sid), "name", "section");
    if (page === "subjects") return pageSimpleList("Subjects", db.subjects.filter(s => s.schoolId === sid), "name", "code");
    if (page === "questions") return pageQuestions();
    if (page === "exams") return pageExams();
    if (page === "marks") return pageMarks();
    if (page === "results") return pageResults(true);
    if (page === "reports") return pageReports();
    if (page === "notices") return pageNotices();
    if (page === "gallery") return pageGallery();
    if (page === "notifications") return pageNotifications();
    if (page === "activity") return pageActivity();

    const school = schoolOf(sid);
    const pending = db.users.filter(u => u.schoolId === sid && u.status === "PENDING").length;
    const students = db.users.filter(u => u.schoolId === sid && u.role === "STUDENT" && u.status === "ACTIVE").length;
    const staff = db.users.filter(u => u.schoolId === sid && u.role === "STAFF" && u.status === "ACTIVE").length;
    const exams = db.exams.filter(e => e.schoolId === sid).length;
    return `
    <div class="page-title">Welcome, ${escapeHtml(session.firstName)}</div>
    <p class="page-sub">${escapeHtml(school?.name || "")} · Code: <strong>${escapeHtml(school?.code || "")}</strong> — share this so users can join</p>
    <div class="grid-4" style="margin-bottom:18px">
      <div class="stat"><div class="lbl">Students</div><div class="val">${students}</div></div>
      <div class="stat"><div class="lbl">Teachers</div><div class="val">${staff}</div></div>
      <div class="stat"><div class="lbl">CBT Exams</div><div class="val">${exams}</div></div>
      <div class="stat"><div class="lbl">Pending</div><div class="val">${pending}</div></div>
    </div>
    ${pending ? `<div class="card" style="padding:14px;margin-bottom:14px;background:var(--gold-soft);border-color:#ffe082">
      <strong>${pending} awaiting approval</strong> — open Users to approve teachers, students and parents.
      <button class="btn btn-gold btn-sm" style="margin-left:8px" data-page="users">Open Users</button>
    </div>` : ""}
    <div class="card" style="padding:14px">
      <strong>Quick actions</strong>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:10px">
        <button class="btn btn-outline btn-sm" data-page="users">Approve users</button>
        <button class="btn btn-outline btn-sm" data-page="exams">CBT exams</button>
        <button class="btn btn-outline btn-sm" data-page="marks">CA & marks</button>
        <button class="btn btn-outline btn-sm" data-page="reports">Report sheets</button>
      </div>
    </div>`;
  }

  function pageUsers() {
    const users = db.users.filter(u => u.schoolId === session.schoolId && u.role !== "ADMIN")
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    const classes = db.classes.filter(c => c.schoolId === session.schoolId);
    const students = db.users.filter(u => u.schoolId === session.schoolId && u.role === "STUDENT" && u.status === "ACTIVE");
    const parents = db.users.filter(u => u.schoolId === session.schoolId && u.role === "PARENT" && u.status === "ACTIVE");
    const pending = users.filter(u => u.status === "PENDING");
    const active = users.filter(u => u.status === "ACTIVE");
    const filterRole = ui.userFilter || "ALL";
    const filtered = (filterRole === "PENDING" ? pending
      : filterRole === "STUDENT" ? active.filter(u => u.role === "STUDENT")
      : filterRole === "STAFF" ? active.filter(u => u.role === "STAFF")
      : filterRole === "PARENT" ? active.filter(u => u.role === "PARENT")
      : users);

    // Detail view when admin opens a person
    if (ui.viewUserId) {
      const u = userOf(ui.viewUserId);
      if (!u || u.schoolId !== session.schoolId) {
        ui.viewUserId = null;
      } else {
        const st = db.students.find(s => s.userId === u.id);
        const sf = db.staff.find(s => s.userId === u.id);
        const pr = db.parents.find(p => p.userId === u.id);
        const marks = db.marksheets.filter(m => m.studentUserId === u.id).slice(0, 8);
        const results = db.results.filter(r => r.userId === u.id).slice(0, 5);
        const linked = (u.role === "PARENT")
          ? db.parentLinks.filter(l => l.parentUserId === u.id).map(l => userOf(l.studentUserId)).filter(Boolean)
          : db.parentLinks.filter(l => l.studentUserId === u.id).map(l => userOf(l.parentUserId)).filter(Boolean);
        return `
        <button type="button" class="btn btn-secondary btn-sm" id="btn-back-users" style="margin-bottom:12px">← Back to users</button>
        <div class="page-title">Person details</div>
        <p class="page-sub">Full profile · ${escapeHtml(u.role)} · ${escapeHtml(u.status)}</p>
        <div class="card" style="padding:18px;margin-bottom:14px">
          <div style="display:flex;gap:16px;flex-wrap:wrap;align-items:flex-start">
            ${u.passport
              ? `<img src="${u.passport}" alt="Passport" style="width:96px;height:96px;border-radius:14px;object-fit:cover;border:1px solid var(--line)">`
              : `<div class="passport-preview empty" style="width:96px;height:96px;font-size:28px">👤</div>`}
            <div style="flex:1;min-width:180px">
              <div style="font-size:20px;font-weight:800">${escapeHtml(u.firstName + " " + u.lastName)}</div>
              <div style="margin-top:6px">
                <span class="badge ${u.status === "ACTIVE" ? "badge-ok" : "badge-warn"}">${u.status}</span>
                <span class="badge badge-info">${u.role}</span>
              </div>
              ${u.status === "PENDING" ? `<button class="btn btn-success btn-sm" style="margin-top:12px" data-approve="${u.id}">✓ Approve this person</button>` : ""}
            </div>
          </div>
        </div>
        <div class="card" style="padding:16px;margin-bottom:14px">
          <h3 style="font-size:14px;margin-bottom:12px;color:var(--green)">1. Account</h3>
          <div class="grid-2" style="gap:10px 16px;font-size:13px">
            <div><span class="hint">Email</span><br><strong>${escapeHtml(u.email)}</strong></div>
            <div><span class="hint">Phone</span><br><strong>${escapeHtml(u.phone || "—")}</strong></div>
            <div><span class="hint">Gender</span><br><strong>${escapeHtml(u.gender || "—")}</strong></div>
            <div><span class="hint">Date of birth</span><br><strong>${escapeHtml(u.dob || "—")}</strong></div>
            <div><span class="hint">Age</span><br><strong>${u.age != null ? u.age : "—"}</strong></div>
            <div><span class="hint">Blood group</span><br><strong>${escapeHtml(u.bloodGroup || "—")}</strong></div>
            <div style="grid-column:1/-1"><span class="hint">Address</span><br><strong>${escapeHtml(u.address || "—")}</strong></div>
            <div><span class="hint">Joined</span><br><strong>${u.createdAt ? new Date(u.createdAt).toLocaleString() : "—"}</strong></div>
          </div>
        </div>
        ${u.role === "STUDENT" ? `
        <div class="card" style="padding:16px;margin-bottom:14px">
          <h3 style="font-size:14px;margin-bottom:12px;color:var(--green)">2. Student information</h3>
          <div class="grid-2" style="gap:10px 16px;font-size:13px">
            <div><span class="hint">Class</span><br><strong>${escapeHtml(classOf(st?.classId)?.name || "Not assigned")}</strong></div>
            <div><span class="hint">Admission No</span><br><strong>${escapeHtml(st?.admissionNumber || "—")}</strong></div>
            <div><span class="hint">Guardian name</span><br><strong>${escapeHtml(st?.guardianName || "—")}</strong></div>
            <div><span class="hint">Guardian phone</span><br><strong>${escapeHtml(st?.guardianPhone || "—")}</strong></div>
          </div>
          ${u.status === "ACTIVE" ? `
          <div class="field" style="margin-top:12px"><label class="label">Assign / change class</label>
            <select class="select" id="detail-class">${classes.map(c => `<option value="${c.id}" ${st?.classId === c.id ? "selected" : ""}>${escapeHtml(c.name)}</option>`).join("")}</select>
          </div>
          <button class="btn btn-primary btn-sm" data-set-class="${u.id}">Save class</button>` : ""}
        </div>
        <div class="card" style="padding:16px;margin-bottom:14px">
          <h3 style="font-size:14px;margin-bottom:10px;color:var(--green)">3. Academic snapshot</h3>
          <p class="hint">Recent CA / CBT</p>
          ${results.length ? results.map(r => {
            const e = db.exams.find(x => x.id === r.examId);
            return `<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--line);font-size:13px">
              <span>${escapeHtml(e?.title || "Exam")}</span>
              <span><strong>${(r.percentage||0).toFixed(1)}%</strong> · ${r.grade} · ${r.status}</span>
            </div>`;
          }).join("") : `<div class="empty" style="padding:12px">No CBT results yet</div>`}
          ${marks.length ? `<p class="hint" style="margin-top:12px">CA rows</p>` + marks.map(m =>
            `<div style="font-size:13px;padding:4px 0">${escapeHtml(subjectOf(m.subjectId)?.name || "")}: CA1 ${m.ca1} CA2 ${m.ca2} Exam ${m.exam} = <strong>${m.total}</strong> ${m.grade} <span class="badge ${m.status==="PENDING"?"badge-warn":"badge-ok"}">${m.status||"OK"}</span></div>`
          ).join("") : ""}
        </div>` : ""}
        ${u.role === "STAFF" ? `
        <div class="card" style="padding:16px;margin-bottom:14px">
          <h3 style="font-size:14px;margin-bottom:12px;color:var(--green)">2. Staff information</h3>
          <div class="grid-2" style="gap:10px 16px;font-size:13px">
            <div><span class="hint">Designation</span><br><strong>${escapeHtml(sf?.designation || "—")}</strong></div>
            <div><span class="hint">Qualification</span><br><strong>${escapeHtml(sf?.qualification || "—")}</strong></div>
            <div><span class="hint">Subjects</span><br><strong>${escapeHtml(sf?.subjects || "—")}</strong></div>
            <div><span class="hint">Next of kin</span><br><strong>${escapeHtml(sf?.nextOfKin || "—")}</strong></div>
          </div>
          ${u.status === "ACTIVE" ? `<button class="btn btn-outline btn-sm" style="margin-top:12px" data-assign="${u.id}">Assign subject / class</button>` : ""}
        </div>` : ""}
        ${linked.length ? `
        <div class="card" style="padding:16px;margin-bottom:14px">
          <h3 style="font-size:14px;margin-bottom:10px;color:var(--green)">Linked family</h3>
          ${linked.map(p => `<div style="font-size:13px;padding:6px 0">${escapeHtml(p.firstName + " " + p.lastName)} · ${p.role}</div>`).join("")}
        </div>` : ""}
        <div id="assign-modal"></div>`;
      }
    }

    function rowCard(u) {
      const st = db.students.find(s => s.userId === u.id);
      const sf = db.staff.find(s => s.userId === u.id);
      const bits = [];
      if (st?.classId) bits.push(classOf(st.classId)?.name || "");
      if (st?.admissionNumber) bits.push(st.admissionNumber);
      if (u.age) bits.push("Age " + u.age);
      if (sf?.designation) bits.push(sf.designation);
      return `<div class="card user-row" style="padding:12px 14px;margin-bottom:8px;cursor:pointer" data-open-user="${u.id}" data-search="${escapeHtml((u.firstName + " " + u.lastName + " " + u.email).toLowerCase())}">
        <div style="display:flex;gap:12px;align-items:center">
          ${u.passport ? `<img src="${u.passport}" class="passport-preview" style="width:48px;height:48px" alt="">` : `<div class="passport-preview empty" style="width:48px;height:48px;font-size:16px">👤</div>`}
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;font-size:14px">${escapeHtml(u.firstName + " " + u.lastName)}</div>
            <div style="font-size:12px;color:var(--muted)">${escapeHtml(u.email)}</div>
            <div style="font-size:11px;color:var(--muted);margin-top:2px">${escapeHtml(bits.filter(Boolean).join(" · ") || u.role)}</div>
          </div>
          <div style="text-align:right">
            <span class="badge ${u.status === "ACTIVE" ? "badge-ok" : "badge-warn"}">${u.status}</span>
            <div style="font-size:11px;color:var(--green);margin-top:6px">View →</div>
          </div>
        </div>
        ${u.status === "PENDING" ? `<div style="margin-top:10px" class="no-print"><button type="button" class="btn btn-success btn-sm" data-approve="${u.id}" onclick="event.stopPropagation()">✓ Approve</button></div>` : ""}
      </div>`;
    }

    return `
    <div class="page-title">Users</div>
    <p class="page-sub">1. Approve new people · 2. Tap a person to see full details · 3. Assign class / subjects</p>
    ${pending.length ? `<div class="card" style="padding:12px 14px;margin-bottom:12px;background:var(--gold-soft);border-color:#ffe082">
      <strong style="color:#856404">${pending.length} waiting for approval</strong>
      <span class="hint"> — open each person to review passport and details, then approve</span>
    </div>` : ""}
    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px" class="no-print">
      ${[["ALL","All"],["PENDING","Pending"],["STUDENT","Students"],["STAFF","Staff"],["PARENT","Parents"]].map(([k,l]) =>
        `<button type="button" class="btn btn-sm ${filterRole === k ? "btn-primary" : "btn-outline"}" data-user-filter="${k}">${l}</button>`
      ).join("")}
    </div>
    <div class="search-bar no-print" style="margin-bottom:12px">
      <input class="input" id="user-search" placeholder="Search name or email…">
    </div>
    <div id="users-list">
      ${filtered.map(rowCard).join("") || "<div class='empty'>No users in this list</div>"}
    </div>
    <div class="card" style="padding:16px;margin-top:16px">
      <h3 style="font-size:15px;margin-bottom:8px">Link parent ↔ child</h3>
      <p class="hint" style="margin-bottom:12px">1) Parent signs up as <strong>Parent</strong> · 2) You approve parent &amp; student · 3) Select them below · 4) Link. Parent can then see that child's results and report cards.</p>
      <div class="grid-2">
        <div class="field"><label class="label">Parent (approved)</label>
          <select class="select" id="link-parent">${parents.map(p => `<option value="${p.id}">${escapeHtml(p.firstName + " " + p.lastName)}</option>`).join("") || "<option value=''>No approved parents yet</option>"}</select></div>
        <div class="field"><label class="label">Student (approved)</label>
          <select class="select" id="link-child">${students.map(s => `<option value="${s.id}">${escapeHtml(s.firstName + " " + s.lastName)}</option>`).join("") || "<option value=''>No approved students yet</option>"}</select></div>
      </div>
      <button class="btn btn-primary btn-sm" id="btn-link-parent">Link parent to student</button>
    </div>
    <div id="assign-modal"></div>`;
  }

  function pageSimpleList(title, items, f1, f2) {
    return `<div class="page-title">${title}</div>
    <div class="grid-3" style="margin-top:14px">${items.map(i =>
      `<div class="card" style="padding:14px"><strong>${escapeHtml(i[f1])}</strong>
      ${f2 && i[f2] ? `<div style="font-size:12px;color:var(--muted)">${escapeHtml(i[f2])}</div>` : ""}</div>`
    ).join("")}</div>`;
  }

  function pageQuestions() {
    const sid = session.schoolId;
    let qs = db.questions.filter(q => q.schoolId === sid);
    const subjects = db.subjects.filter(s => s.schoolId === sid);
    const classes = db.classes.filter(c => c.schoolId === sid);
    const showBulk = !qs.length || ui.showBulk;
    return `
    <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:14px">
      <div class="page-title">Question Bank</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn btn-gold btn-sm" id="btn-bulk-q">📥 Upload Excel / CSV</button>
        <button type="button" class="btn btn-primary btn-sm" id="btn-new-q">+ Add one</button>
      </div>
    </div>
    ${!qs.length ? `<div class="card" style="padding:14px;margin-bottom:12px;background:var(--gold-soft);border-color:#ffe082">
      <strong>No questions yet.</strong> Upload a CSV/Excel file below, then create a CBT exam.
    </div>` : ""}
    <div id="bulk-form" class="${showBulk ? "" : "hidden"} card" style="padding:14px;margin-bottom:12px">
      <p class="hint" style="margin-bottom:8px"><strong>Excel/CSV headers (row 1):</strong><br>
      <code>question, optionA, optionB, optionC, optionD, correct, marks</code><br>
      <code>correct</code> can be the full answer text or letter A/B/C/D.<br>
      <a href="assets/questions-template.csv" download style="color:var(--green);font-weight:600">Download sample CSV</a></p>
      <div class="grid-2">
        <select class="select" id="bulk-subj">${subjects.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join("")}</select>
        <select class="select" id="bulk-class"><option value="">Any class</option>${classes.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("")}</select>
      </div>
      <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:8px;align-items:center">
        <label class="btn btn-primary btn-sm" style="cursor:pointer;margin:0">
          <input type="file" id="bulk-file" accept=".xlsx,.xls,.csv,text/csv" style="display:none">
          Choose Excel or CSV file
        </label>
        <a class="btn btn-outline btn-sm" href="assets/questions-template.csv" download>Download sample CSV</a>
        <button type="button" class="btn btn-secondary btn-sm" id="btn-cancel-bulk">Cancel</button>
      </div>
      <p class="hint" style="margin-top:8px">Tip: If Excel fails, open in Google Sheets → Download → Comma-separated values (.csv)</p>
    </div>
    <div id="q-form" class="hidden card" style="padding:14px;margin-bottom:12px">
      <div class="field"><label class="label">Question</label><textarea class="input" id="q-text" rows="2"></textarea></div>
      <div class="grid-2">
        <select class="select" id="q-subj">${subjects.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join("")}</select>
        <select class="select" id="q-class"><option value="">Any</option>${classes.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("")}</select>
      </div>
      <div class="field" style="margin-top:10px"><label class="label">Options (one per line)</label><textarea class="input" id="q-opts" rows="4"></textarea></div>
      <div class="grid-2">
        <div class="field"><label class="label">Correct answer</label><input class="input" id="q-correct"></div>
        <div class="field"><label class="label">Marks</label><input class="input" id="q-marks" type="number" value="1"></div>
      </div>
      <button class="btn btn-primary btn-sm" id="btn-save-q">Save</button>
      <button class="btn btn-secondary btn-sm" id="btn-cancel-q">Cancel</button>
    </div>
    ${qs.length ? `<div class="table-wrap"><table><thead><tr><th>Question</th><th>Subject</th><th>Marks</th><th class='no-print'></th></tr></thead>
      <tbody>${qs.map(q => `<tr>
        <td>${escapeHtml(q.text).slice(0, 80)}</td>
        <td>${escapeHtml(subjectOf(q.subjectId)?.name || "—")}</td>
        <td>${q.marks || 1}</td>
        <td class="no-print">${(session.role === "ADMIN" || session.role === "STAFF") ? `<button type="button" class="btn btn-danger btn-sm" data-del-q="${q.id}">Delete</button>` : ""}</td>
      </tr>`).join("")}</tbody></table></div>`
      : `<div class="empty">No questions yet</div>`}`;
  }

  function pageExams() {
    const sid = session.schoolId;
    let exams = db.exams.filter(e => e.schoolId === sid);
    if (session.role === "STAFF") exams = exams.filter(e => e.createdBy === session.id);
    const subjects = db.subjects.filter(s => s.schoolId === sid);
    const classes = db.classes.filter(c => c.schoolId === sid);
    const qs = db.questions.filter(q => q.schoolId === sid);
    return `
    <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:14px">
      <div class="page-title">CBT Examinations</div>
      ${session.role !== "STUDENT" && session.role !== "PARENT" ? `<button class="btn btn-primary btn-sm" id="btn-new-exam">+ Create exam</button>` : ""}
    </div>
    <div id="exam-form" class="hidden card" style="padding:14px;margin-bottom:12px">
      <div class="field"><label class="label">Title</label><input class="input" id="ex-title"></div>
      <div class="grid-2">
        <select class="select" id="ex-subj">${subjects.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join("")}</select>
        <select class="select" id="ex-class">${classes.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("")}</select>
      </div>
      <div class="grid-2" style="margin-top:10px">
        <div class="field"><label class="label">Duration (mins)</label><input class="input" id="ex-dur" type="number" value="40"></div>
        <div class="field"><label class="label">Pass mark %</label><input class="input" id="ex-pass" type="number" value="40"></div>
      </div>
      <div class="field"><label class="label">Questions</label>
        ${qs.length ? `
        <div style="max-height:160px;overflow:auto;border:1px solid var(--line);border-radius:10px;padding:8px">
          ${qs.map(q => `<label style="display:flex;gap:8px;font-size:13px;padding:3px"><input type="checkbox" class="ex-q" value="${q.id}"> ${escapeHtml(q.text).slice(0, 60)}</label>`).join("")}
        </div>` : `
        <div class="card" style="padding:14px;background:var(--gold-soft);border-color:#ffe082">
          <strong>No questions in the bank yet</strong>
          <p class="hint" style="margin:8px 0">Upload CSV/Excel first, then come back to create the exam.</p>
          <button type="button" class="btn btn-gold btn-sm" id="btn-go-questions">Go to Question Bank &amp; Upload</button>
        </div>
        <div id="exam-bulk-box" class="card" style="padding:14px;margin-top:10px">
          <p style="font-size:13px;font-weight:600;margin-bottom:8px">Or upload here now</p>
          <p class="hint">Headers: question, optionA, optionB, optionC, optionD, correct, marks</p>
          <label class="btn btn-primary btn-sm" style="cursor:pointer;margin-top:8px">
            <input type="file" id="bulk-file" accept=".xlsx,.xls,.csv,text/csv" style="display:none">
            Choose CSV or Excel
          </label>
          <a class="btn btn-outline btn-sm" href="assets/questions-template.csv" download style="margin-left:6px">Sample CSV</a>
        </div>`}
      </div>
      <button class="btn btn-primary btn-sm" id="btn-save-exam" ${qs.length ? "" : "disabled"}>Save draft</button>
      <button class="btn btn-secondary btn-sm" id="btn-cancel-exam">Cancel</button>
    </div>
    ${exams.map(e => `<div class="card" style="padding:14px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
      <div>
        <strong>${escapeHtml(e.title)}</strong>
        <div style="font-size:12px;color:var(--muted)">${escapeHtml(subjectOf(e.subjectId)?.name || "")} · ${e.durationMinutes || 40} min · ${(e.questionIds || []).length} Qs</div>
        <span class="badge ${e.status === "PUBLISHED" ? "badge-ok" : "badge-warn"}" style="margin-top:6px">${e.status}</span>
      </div>
      <div>
        ${session.role === "ADMIN" && e.status !== "PUBLISHED" ? `<button class="btn btn-success btn-sm" data-publish-exam="${e.id}">Publish</button>` : ""}
        ${session.role === "STUDENT" && e.status === "PUBLISHED" ? `<button class="btn btn-primary btn-sm" data-start-exam="${e.id}">Start CBT</button>` : ""}
      </div>
    </div>`).join("") || "<div class='empty'>No examinations</div>"}`;
  }

  function pageMarks() {
    const sid = session.schoolId;
    const classes = db.classes.filter(c => c.schoolId === sid);
    const subjects = db.subjects.filter(s => s.schoolId === sid);
    let staffClasses = classes;
    if (session.role === "STAFF") {
      const aids = db.assignments.filter(a => a.userId === session.id).map(a => a.classId);
      staffClasses = classes.filter(c => aids.includes(c.id));
    }
    const classId = ui.markClass || staffClasses[0]?.id;
    const subjectId = ui.markSubj || subjects[0]?.id;
    const students = db.students.filter(s => s.classId === classId).map(s => userOf(s.userId)).filter(Boolean);
    const sess = currentSession(sid);
    const term = currentTerm(sid);

    return `
    <div class="page-title">Continuous Assessment (CA)</div>
    <p class="page-sub">${escapeHtml(sess?.name || "")} · ${escapeHtml(term?.name || "")} — <strong>Type CA1 (15) + CA2 (15) only</strong>. Exam (60) fills from CBT automatically.</p>
    <div class="grid-2" style="margin-bottom:14px">
      <div class="field"><label class="label">Class</label>
        <select class="select" id="mark-class">${staffClasses.map(c => `<option value="${c.id}" ${c.id === classId ? "selected" : ""}>${escapeHtml(c.name)}</option>`).join("")}</select></div>
      <div class="field"><label class="label">Subject</label>
        <select class="select" id="mark-subj">${subjects.map(s => `<option value="${s.id}" ${s.id === subjectId ? "selected" : ""}>${escapeHtml(s.name)}</option>`).join("")}</select></div>
    </div>
    ${students.length === 0 ? `<div class="empty">No students in this class. Assign students to classes first.</div>` : `
    <div class="card" style="padding:12px;margin-bottom:12px;background:var(--green-soft)">
      <strong>Type CA only.</strong> <span class="hint">Exam /60 is filled from CBT automatically (not typed).</span>
    </div>
    <div class="table-wrap"><table class="mass-input-grid">
      <thead><tr><th>Student</th><th>CA1 /15</th><th>CA2 /15</th><th>Exam /60 (CBT auto)</th><th>Total</th><th>Grade</th></tr></thead>
      <tbody>${students.map(u => {
        const m = db.marksheets.find(x =>
          x.studentUserId === u.id && x.subjectId === subjectId &&
          x.sessionName === (sess?.name || "") && x.termName === (term?.name || "")
        );
        const ca1 = m?.ca1 ?? "", ca2 = m?.ca2 ?? "";
        const cbt = db.results.filter(r => r.userId === u.id && r.subjectId === subjectId)
          .sort((a,b) => (b.at||0)-(a.at||0))[0];
        const exam = cbt ? Math.round(((cbt.percentage||0)/100)*60*10)/10 : "";
        const total = (parseFloat(ca1) || 0) + (parseFloat(ca2) || 0) + (parseFloat(exam) || 0);
        return `<tr data-stu="${u.id}">
          <td>${escapeHtml(u.firstName + " " + u.lastName)}</td>
          <td><input type="number" class="m-ca1" min="0" max="15" step="0.5" value="${ca1}"></td>
          <td><input type="number" class="m-ca2" min="0" max="15" step="0.5" value="${ca2}"></td>
          <td><strong style="color:var(--green)">${exam !== "" ? exam : "—"}</strong>
            <input type="hidden" class="m-exam" value="${exam}"></td>
          <td class="m-total">${total || "—"}</td>
          <td class="m-grade">${total ? waecGrade(total) : "—"}</td>
        </tr>`;
      }).join("")}</tbody>
    </table></div>
    <button class="btn btn-primary" style="margin-top:14px" id="btn-save-marks">${session.role === "ADMIN" ? "Save CA (approved)" : "Submit CA for admin approval"}</button>`}
    ${session.role === "ADMIN" ? (() => {
      const pending = db.marksheets.filter(m => m.schoolId === sid && m.status === "PENDING");
      if (!pending.length) return `<p class="hint" style="margin-top:12px">No CA waiting for approval</p>`;
      return `<div class="card" style="padding:14px;margin-top:16px;border-color:#ffe082;background:var(--gold-soft)">
        <strong>${pending.length} CA entry(ies) waiting for your approval</strong>
        <p class="hint" style="margin:8px 0">Staff submitted these scores. Review then approve.</p>
        <button type="button" class="btn btn-success btn-sm" id="btn-approve-all-ca">Approve all pending CA</button>
      </div>`;
    })() : ""}`;
  }

  function pageAttendance() {
    const sid = session.schoolId;
    let classes = db.classes.filter(c => c.schoolId === sid);
    if (session.role === "STAFF") {
      const aids = db.assignments.filter(a => a.userId === session.id).map(a => a.classId);
      classes = classes.filter(c => aids.includes(c.id));
    }
    const classId = ui.attClass || classes[0]?.id;
    const dateStr = ui.attDate || new Date().toISOString().slice(0, 10);
    const students = db.students.filter(s => s.classId === classId).map(s => userOf(s.userId)).filter(Boolean);

    return `
    <div class="page-title">Attendance Register</div>
    <p class="page-sub">Mark Present, Absent or Late for today</p>
    <div class="grid-2" style="margin-bottom:14px">
      <div class="field"><label class="label">Class</label>
        <select class="select" id="att-class">${classes.map(c => `<option value="${c.id}" ${c.id === classId ? "selected" : ""}>${escapeHtml(c.name)}</option>`).join("")}</select></div>
      <div class="field"><label class="label">Date</label>
        <input class="input" type="date" id="att-date" value="${dateStr}"></div>
    </div>
    ${students.length === 0 ? `<div class="empty">No students in class</div>` : `
    <div class="card" style="padding:8px 0">
      ${students.map(u => {
        const existing = db.attendance.find(a => a.studentUserId === u.id && a.classId === classId && a.date === dateStr);
        const st = existing?.status || "PRESENT";
        return `<div class="att-row" data-stu="${u.id}" style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px;border-bottom:1px solid #f1f3f5">
          <span style="font-weight:500">${escapeHtml(u.firstName + " " + u.lastName)}</span>
          <div class="att-toggle">
            <button type="button" data-st="PRESENT" class="${st === "PRESENT" ? "on-p" : ""}">Present</button>
            <button type="button" data-st="ABSENT" class="${st === "ABSENT" ? "on-a" : ""}">Absent</button>
            <button type="button" data-st="LATE" class="${st === "LATE" ? "on-l" : ""}">Late</button>
          </div>
        </div>`;
      }).join("")}
    </div>
    <button class="btn btn-primary" style="margin-top:14px" id="btn-save-att">Save attendance</button>`}`;
  }

  function pageResults(isAdmin) {
    let results = isAdmin || session.role === "ADMIN"
      ? db.results.filter(r => r.schoolId === session.schoolId)
      : session.role === "PARENT"
      ? db.results.filter(r => parentChildren().some(c => c.user?.id === r.userId) && r.status === "PUBLISHED")
      : db.results.filter(r => r.userId === session.id && r.status === "PUBLISHED");
    if (session.role === "STAFF") {
      const my = db.exams.filter(e => e.createdBy === session.id).map(e => e.id);
      results = db.results.filter(r => my.includes(r.examId));
    }
    results = results.sort((a, b) => b.at - a.at);
    return `
    <div class="page-title">CBT Results</div>
    <p class="page-sub">Auto-marked from exams · WAEC grades (A1–F9). After publish, use <strong>Report Sheets</strong> to build report cards (no typing scores).</p>
    ${results.map(r => {
      const u = userOf(r.userId);
      const e = db.exams.find(x => x.id === r.examId);
      return `<div class="card" style="padding:14px;margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px">
          <div>
            <strong>${escapeHtml(u ? u.firstName + " " + u.lastName : "—")}</strong>
            <div style="font-size:12px;color:var(--muted)">${escapeHtml(e?.title || "")}</div>
            <div style="margin-top:6px">${r.percentage.toFixed(1)}% · <span class="badge badge-info">${r.grade}</span>
              <span class="badge ${r.status === "PUBLISHED" ? "badge-ok" : "badge-warn"}">${r.status}</span></div>
          </div>
          <div class="no-print">
            ${(session.role === "ADMIN") && r.status !== "PUBLISHED" ? `<button class="btn btn-primary btn-sm" data-publish-result="${r.id}">Publish</button>` : ""}
            <button class="btn btn-outline btn-sm" data-print-result="${r.id}">Print PDF</button>
          </div>
        </div>
      </div>`;
    }).join("") || "<div class='empty'>No results</div>"}
    <div id="print-area"></div>`;
  }

  function pageReports() {
    const isAdmin = session.role === "ADMIN";
    const isStaff = session.role === "STAFF";
    const students = db.users.filter(u => u.schoolId === session.schoolId && u.role === "STUDENT" && u.status === "ACTIVE");
    const classes = db.classes.filter(c => c.schoolId === session.schoolId);
    let cards = db.reportCards.filter(r => r.schoolId === session.schoolId);
    if (session.role === "STUDENT") cards = cards.filter(c => c.userId === session.id && c.status === "PUBLISHED");
    if (session.role === "PARENT") {
      const ids = parentChildren().map(c => c.user?.id);
      cards = cards.filter(c => ids.includes(c.userId) && c.status === "PUBLISHED");
    }
    const cbtReady = students.filter(s => db.results.some(r => r.userId === s.id)).length;

    return `
    <div class="page-title">Termly Report Sheets</div>
    <p class="page-sub"><strong>CA</strong> = typed by teacher/admin · <strong>Exam</strong> = from CBT automatically · Total &amp; grade calculated for you</p>
    ${(isAdmin || isStaff) ? `
    <div class="card" style="padding:14px;margin-bottom:14px;background:var(--green-soft);border-color:#c5cae9">
      <strong>How it works</strong>
      <p class="hint" style="margin-top:6px">1) Enter <strong>CA1 &amp; CA2</strong> under CA &amp; Marks · 2) Students write <strong>CBT</strong> (exam score auto) · 3) Publish CBT result · 4) Generate report card · 5) Publish for students</p>
      <p class="hint">${cbtReady} student(s) have CBT scores ready</p>
    </div>
    <div class="card" style="padding:14px;margin-bottom:14px">
      <h3 style="font-size:14px;margin-bottom:10px">Auto-generate from CBT</h3>
      <div class="field"><label class="label">One student</label>
        <select class="select" id="rc-student">
          <option value="">Select student…</option>
          ${students.map(s => {
            const has = db.results.some(r => r.userId === s.id);
            return `<option value="${s.id}">${escapeHtml(s.firstName + " " + s.lastName)}${has ? " ✓ CBT" : ""}</option>`;
          }).join("")}
        </select>
      </div>
      <button class="btn btn-primary btn-sm" id="btn-gen-rc">Generate from CBT scores</button>
      <hr style="border:none;border-top:1px solid var(--line);margin:14px 0">
      <div class="field"><label class="label">Or whole class</label>
        <select class="select" id="rc-class">
          <option value="">All classes with CBT results</option>
          ${classes.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("")}
        </select>
      </div>
      <button class="btn btn-gold btn-sm" id="btn-gen-rc-all">Generate all from CBT</button>
    </div>
    ${isAdmin ? `
    <div class="card" style="padding:14px;margin-bottom:14px">
      <h3 style="font-size:14px;margin-bottom:8px">Principal signature &amp; school stamp</h3>
      <p class="hint" style="margin-bottom:10px">These appear on every printed report card. Upload a clear PNG/JPG (signature on white background works best).</p>
      <div class="grid-2">
        <div>
          <label class="label">Principal / Admin signature</label>
          ${schoolOf(session.schoolId)?.signature ? `<img src="${schoolOf(session.schoolId).signature}" alt="Sig" style="max-height:48px;display:block;margin:8px 0">` : `<p class="hint">No signature yet</p>`}
          <label class="btn btn-outline btn-sm" style="cursor:pointer">
            <input type="file" id="sig-file" accept="image/*" style="display:none"> Upload signature
          </label>
        </div>
        <div>
          <label class="label">School stamp</label>
          ${schoolOf(session.schoolId)?.stamp ? `<img src="${schoolOf(session.schoolId).stamp}" alt="Stamp" style="max-height:72px;display:block;margin:8px 0">` : `<p class="hint">No stamp yet</p>`}
          <label class="btn btn-outline btn-sm" style="cursor:pointer">
            <input type="file" id="stamp-file" accept="image/*" style="display:none"> Upload stamp
          </label>
        </div>
      </div>
    </div>` : ""}` : ""}
    ${cards.map(rc => {
      const u = userOf(rc.userId);
      return `<div class="card" style="padding:14px;margin-bottom:10px">
        <strong>${escapeHtml(u ? u.firstName + " " + u.lastName : "")}</strong>
        <div style="font-size:12px;color:var(--muted)">${escapeHtml(rc.termName || "")} · ${escapeHtml(rc.sessionName || "")} · Avg ${rc.average?.toFixed(1)}% (${rc.overallGrade})</div>
        <span class="badge ${rc.status === "PUBLISHED" ? "badge-ok" : "badge-warn"}">${rc.status}</span>
        <div style="margin-top:10px" class="no-print">
          ${isAdmin && rc.status !== "PUBLISHED" ? `<button class="btn btn-success btn-sm" data-publish-rc="${rc.id}">Publish</button>` : ""}
          <button class="btn btn-outline btn-sm" data-print-rc="${rc.id}">Print / PDF</button>
        </div>
      </div>`;
    }).join("") || "<div class='empty'>No report cards yet</div>"}
    <div id="print-area"></div>`;
  }

  function pageNotices() {
    const notices = db.notices.filter(n => n.schoolId === session.schoolId);
    return `
    <div class="page-title">Notices & Announcements</div>
    ${(session.role === "ADMIN" || session.role === "STAFF") ? `
    <div class="card" style="padding:14px;margin-bottom:14px">
      <div class="field"><label class="label">Title</label><input class="input" id="notice-title"></div>
      <div class="field"><label class="label">Message</label><textarea class="input" id="notice-body" rows="3"></textarea></div>
      <button class="btn btn-primary btn-sm" id="btn-post-notice">Post notice</button>
    </div>` : ""}
    ${notices.map(n => `<div class="card" style="padding:14px;margin-bottom:8px">
      <strong>${escapeHtml(n.title)}</strong>
      <p style="font-size:14px;margin-top:6px">${escapeHtml(n.body)}</p>
      <div style="font-size:11px;color:var(--muted);margin-top:6px">${new Date(n.at).toLocaleString()}</div>
    </div>`).join("") || "<div class='empty'>No notices</div>"}`;
  }


  function pageGallery() {
    const sid = session.schoolId;
    const isAdmin = session.role === "ADMIN";
    const captions = [
      "Students in assembly", "Classroom moment", "Girls assembly",
      "Trophy presentation", "Eniola Grace Idowu — Spelling Bee",
      "Champions with trophies", "Interview moment", "School event",
      "Nigeria Spelling Bee Champion", "Management at event", "Group celebration"
    ];
    const builtIn = [];
    for (let i = 1; i <= 11; i++) {
      builtIn.push({ id: "builtin_" + i, src: "assets/gallery/g" + i + ".jpg", caption: captions[i - 1] || "Montclair", builtin: true });
    }
    const uploaded = (db.galleryImages || []).filter(g => g.schoolId === sid || !g.schoolId);
    const imgs = builtIn.concat(uploaded.map(g => ({
      id: g.id, src: g.src, caption: g.caption || "School gallery", builtin: false, by: g.by, at: g.at
    })));

    return `
    <div class="page-title">School Gallery</div>
    <p class="page-sub">Montclair Group of Schools — Knowledge · Power${isAdmin ? " · Admin can add photos" : ""}</p>
    <img src="assets/banner.jpeg" alt="Montclair" class="brand-banner" onerror="this.style.display='none'">
    ${isAdmin ? `
    <div class="card" style="padding:14px;margin-bottom:14px">
      <h3 style="font-size:15px;margin-bottom:10px">Upload to gallery</h3>
      <p class="hint" style="margin-bottom:10px">Photos you upload appear for Staff and Students immediately.</p>
      <div class="field"><label class="label">Caption (optional)</label>
        <input class="input" id="gal-caption" placeholder="e.g. Inter-house sports 2026"></div>
      <label class="btn btn-primary btn-sm" style="cursor:pointer">
        <input type="file" id="gal-file" accept="image/*" style="display:none">
        Choose image
      </label>
      <span id="gal-status" class="hint" style="margin-left:8px"></span>
    </div>` : ""}
    <div class="gallery-grid">
      ${imgs.map((im, idx) => `
        <div style="position:relative">
          <img src="${im.src}" alt="${escapeHtml(im.caption)}" title="${escapeHtml(im.caption)}" data-gallery="${idx}" data-gal-src="${im.src}">
          ${isAdmin && !im.builtin ? `<button type="button" class="btn btn-danger btn-sm" data-del-gal="${im.id}" style="position:absolute;top:6px;right:6px;height:28px;padding:0 8px;font-size:11px">Delete</button>` : ""}
        </div>`).join("")}
    </div>
    <div id="lightbox" class="hidden"></div>
    <script type="application/json" id="gal-data">${JSON.stringify(imgs.map(i => ({ src: i.src, caption: i.caption }))).replace(/</g, "\\u003c")}</script>`;
  }

  function pageNotifications() {
    const sid = session.schoolId;
    const isAdmin = session.role === "ADMIN";
    let list;
    if (isAdmin) {
      // All notifications for this school (admin + students + staff)
      list = (db.notifications || [])
        .filter(n => {
          const u = userOf(n.userId);
          return u && u.schoolId === sid;
        })
        .sort((a, b) => (b.at || 0) - (a.at || 0))
        .slice(0, 100);
    } else {
      list = (db.notifications || [])
        .filter(n => n.userId === session.id)
        .sort((a, b) => (b.at || 0) - (a.at || 0))
        .slice(0, 50);
    }
    // Mark own as read
    (db.notifications || []).forEach(n => {
      if (n.userId === session.id) n.isRead = true;
    });
    saveDBLocal();

    return `
    <div class="page-title">${isAdmin ? "Notifications (all users)" : "My notifications"}</div>
    <p class="page-sub">${isAdmin ? "See alerts for students, staff and admin (approvals, CBT, results)" : "Your latest updates"}</p>
    ${isAdmin ? `
    <div class="card" style="padding:14px;margin-bottom:14px">
      <h3 style="font-size:14px;margin-bottom:8px">Send notice to everyone</h3>
      <div class="field"><label class="label">Title</label><input class="input" id="bcast-title" placeholder="e.g. Exam timetable"></div>
      <div class="field"><label class="label">Message</label><textarea class="input" id="bcast-body" rows="3"></textarea></div>
      <button type="button" class="btn btn-primary btn-sm" id="btn-bcast">Send to all students &amp; staff</button>
    </div>` : ""}
    ${list.length ? list.map(n => {
      const u = userOf(n.userId);
      return `<div class="card" style="padding:12px 14px;margin-bottom:8px;${n.isRead ? "" : "border-color:#c5cae9;background:#f5f7ff"}">
        <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap">
          <strong style="font-size:14px">${escapeHtml(n.title || "Notice")}</strong>
          <span style="font-size:11px;color:var(--muted)">${n.at ? new Date(n.at).toLocaleString() : ""}</span>
        </div>
        <p style="font-size:13px;margin-top:6px">${escapeHtml(n.message || "")}</p>
        ${isAdmin && u ? `<div style="font-size:12px;color:var(--muted);margin-top:6px">To: ${escapeHtml(u.firstName + " " + u.lastName)} (${u.role})</div>` : ""}
      </div>`;
    }).join("") : `<div class="empty">No notifications yet</div>`}`;
  }

  function pageActivity() {
    const logs = db.activity.filter(a => a.schoolId === session.schoolId).slice(0, 60);
    return `
    <div class="page-title">Activity log</div>
    <div class="table-wrap"><table>
      <thead><tr><th>When</th><th>User</th><th>Action</th><th>Details</th></tr></thead>
      <tbody>${logs.map(l => {
        const u = userOf(l.userId);
        return `<tr>
          <td style="white-space:nowrap">${new Date(l.at).toLocaleString()}</td>
          <td>${escapeHtml(u ? u.firstName + " " + u.lastName : "—")}</td>
          <td><span class="badge badge-info">${escapeHtml(l.action)}</span></td>
          <td>${escapeHtml(l.details)}</td>
        </tr>`;
      }).join("") || "<tr><td colspan='4' class='empty'>No activity</td></tr>"}</tbody>
    </table></div>`;
  }

  function pageNursery() {
    const sid = session.schoolId;
    if (session.role === "PARENT") {
      const children = parentChildren().filter(c => c.class?.section === "NURSERY" || (c.class?.name || "").toLowerCase().includes("nursery"));
      const activeId = ui.childId || children[0]?.user?.id;
      const notes = db.dailyNotes.filter(n => n.studentUserId === activeId).slice(0, 14);
      return `
      <div class="page-title">Daily nursery notes</div>
      ${children.length > 1 ? `<div class="field"><label class="label">Child</label>
        <select class="select" id="parent-child-sel">${children.map(c =>
          `<option value="${c.user.id}" ${c.user.id === activeId ? "selected" : ""}>${escapeHtml(c.user.firstName)} (${escapeHtml(c.class?.name || "")})</option>`
        ).join("")}</select></div>` : ""}
      ${notes.map(n => `<div class="nursery-card" style="margin-bottom:10px">
        <div style="font-weight:700;margin-bottom:8px">${n.date}</div>
        <div>🥪 Meal: ${escapeHtml(n.meal || "—")}</div>
        <div>😴 Nap: ${escapeHtml(n.nap || "—")}</div>
        <div>🎨 Activity: ${escapeHtml(n.activity || "—")}</div>
        <div>😊 Mood: ${escapeHtml(n.mood || "—")}</div>
        <div style="margin-top:8px;font-style:italic">📝 ${escapeHtml(n.teacherNote || "")}</div>
      </div>`).join("") || "<div class='empty'>No daily notes yet</div>"}`;
    }
    /* Staff/Admin entry */
    const nurseryClasses = db.classes.filter(c => c.schoolId === sid && (c.section === "NURSERY" || (c.name || "").toLowerCase().includes("nursery")));
    const classId = ui.nClass || nurseryClasses[0]?.id;
    const students = db.students.filter(s => s.classId === classId).map(s => userOf(s.userId)).filter(Boolean);
    return `
    <div class="page-title">Nursery daily notes</div>
    <p class="page-sub">Meal, nap, activity, mood — parents see these in their portal</p>
    <div class="field"><label class="label">Nursery class</label>
      <select class="select" id="n-class">${nurseryClasses.map(c => `<option value="${c.id}" ${c.id === classId ? "selected" : ""}>${escapeHtml(c.name)}</option>`).join("") || "<option>No nursery class</option>"}</select></div>
    ${students.map(u => `
    <div class="card" style="padding:14px;margin-bottom:10px">
      <strong>${escapeHtml(u.firstName + " " + u.lastName)}</strong>
      <div class="grid-2" style="margin-top:8px">
        <div class="field"><label class="label">Meal</label><input class="input n-meal" data-stu="${u.id}" placeholder="Finished everything"></div>
        <div class="field"><label class="label">Nap</label><input class="input n-nap" data-stu="${u.id}" placeholder="Slept 1 hour"></div>
        <div class="field"><label class="label">Activity</label><input class="input n-act" data-stu="${u.id}" placeholder="Letter tracing"></div>
        <div class="field"><label class="label">Mood</label><input class="input n-mood" data-stu="${u.id}" placeholder="Happy"></div>
      </div>
      <div class="field"><label class="label">Teacher note</label><input class="input n-note" data-stu="${u.id}" placeholder="Optional comment"></div>
      <button class="btn btn-primary btn-sm btn-save-note" data-stu="${u.id}">Save note</button>
    </div>`).join("") || "<div class='empty'>Assign students to a Nursery class first</div>"}`;
  }

  function viewStaff() {
    const page = ui.page || "dashboard";
    if (page === "marks") return pageMarks();
    if (page === "attendance") return pageAttendance();
    if (page === "questions") return pageQuestions();
    if (page === "exams") return pageExams();
    if (page === "results") return pageResults(false);
    if (page === "nursery") return pageNursery();
    if (page === "notices") return pageNotices();
    if (page === "gallery") return pageGallery();
    if (page === "notifications") return pageNotifications();
    const assigns = db.assignments.filter(a => a.userId === session.id);
    return `
    <div class="page-title">Hello, ${escapeHtml(session.firstName)}</div>
    <p class="page-sub">Teacher workspace — CA, attendance, CBT</p>
    <div class="grid-2" style="margin-bottom:16px">
      <button class="btn btn-primary" data-page="marks">Enter CA marks</button>
      <button class="btn btn-outline" data-page="attendance">Mark attendance</button>
    </div>
    <h3 style="font-size:14px;margin-bottom:8px">Your assignments</h3>
    ${assigns.length ? assigns.map(a => `<div class="card" style="padding:12px;margin-bottom:6px">
      <strong>${escapeHtml(subjectOf(a.subjectId)?.name || "")}</strong>
      <span style="color:var(--muted)"> · ${escapeHtml(classOf(a.classId)?.name || "")}</span>
    </div>`).join("") : `<div class="empty">No subject assignments yet — ask admin</div>`}`;
  }

  function viewStudent() {
    if (ui.cbt) return viewCBT(ui.cbt);
    const page = ui.page || "dashboard";
    const student = db.students.find(s => s.userId === session.id);
    if (page === "exams") return pageExams();
    if (page === "results") return pageResults(false);
    if (page === "reports") return pageReports();
    if (page === "notices") return pageNotices();
    if (page === "gallery") return pageGallery();
    if (page === "notifications") return pageNotifications();
    const school = schoolOf(session.schoolId);
    const exams = db.exams.filter(e =>
      e.schoolId === session.schoolId && e.status === "PUBLISHED" &&
      (!e.classId || e.classId === student?.classId)
    );
    const available = exams.filter(e => {
      const att = db.attempts.find(a => a.examId === e.id && a.userId === session.id);
      return !att || att.status === "IN_PROGRESS";
    });
    return `
    <div style="display:flex;gap:12px;align-items:center;margin-bottom:16px">
      ${school?.logo ? `<img src="${school.logo}" style="width:52px;height:52px;border-radius:12px;object-fit:cover">` : ""}
      <div>
        <div class="page-title">Hello, ${escapeHtml(session.firstName)}</div>
        <p class="page-sub" style="margin:0">${escapeHtml(classOf(student?.classId)?.name || "No class")} · ${escapeHtml(school?.name || "")}</p>
      </div>
    </div>
    <div class="grid-2" style="margin-bottom:16px">
      <div class="stat"><div class="lbl">Available CBT</div><div class="val">${available.length}</div></div>
      <div class="stat"><div class="lbl">Published results</div><div class="val">${db.results.filter(r => r.userId === session.id && r.status === "PUBLISHED").length}</div></div>
    </div>
    <h3 style="font-size:14px;margin-bottom:8px">Available exams</h3>
    ${available.length ? available.slice(0, 5).map(e => `<div class="card" style="padding:12px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center">
      <div><strong>${escapeHtml(e.title)}</strong><div style="font-size:12px;color:var(--muted)">${e.durationMinutes || 40} min</div></div>
      <button class="btn btn-primary btn-sm" data-start-exam="${e.id}">Start</button>
    </div>`).join("") : `<div class="empty">No exams right now</div>`}`;
  }

  function viewParent() {
    const page = ui.page || "dashboard";
    const children = parentChildren();
    if (!children.length && page === "dashboard") {
      return `<div class="page-title">Parent portal</div>
        <div class="empty">No children linked yet. Ask the school admin to link your account to your child's student profile.</div>`;
    }
    const active = children.find(c => c.user.id === ui.childId) || children[0];
    if (page === "results") return pageResults(false);
    if (page === "reports") return pageReports();
    if (page === "notices") return pageNotices();
    if (page === "nursery") return pageNursery();
    if (page === "gallery") return pageGallery();
    if (page === "notifications") return pageNotifications();

    const notes = active ? db.dailyNotes.filter(n => n.studentUserId === active.user.id).slice(0, 3) : [];
    const marks = active ? db.marksheets.filter(m => m.studentUserId === active.user.id).slice(0, 6) : [];

    return `
    <div class="page-title">Parent portal</div>
    <p class="page-sub">Monitor academic progress (no fees on this portal)</p>
    ${children.length > 1 ? `
    <div class="child-switch" style="margin-bottom:14px">
      <span>🔄 Viewing:</span>
      <select class="select" id="parent-child-sel" style="width:auto;height:36px;border:none;background:transparent;font-weight:700;color:var(--green)">
        ${children.map(c => `<option value="${c.user.id}" ${active && c.user.id === active.user.id ? "selected" : ""}>${escapeHtml(c.user.firstName)} — ${escapeHtml(c.class?.name || "No class")}</option>`).join("")}
      </select>
    </div>` : active ? `<div class="child-switch" style="margin-bottom:14px">${escapeHtml(active.user.firstName + " " + active.user.lastName)} · ${escapeHtml(active.class?.name || "")}</div>` : ""}
    ${active ? `
    <div class="grid-2" style="margin-bottom:14px">
      <div class="stat"><div class="lbl">Class</div><div class="val" style="font-size:16px">${escapeHtml(active.class?.name || "—")}</div></div>
      <div class="stat"><div class="lbl">Adm No</div><div class="val" style="font-size:14px">${escapeHtml(active.student?.admissionNumber || "—")}</div></div>
    </div>
    <h3 style="font-size:14px;margin-bottom:8px">Recent CA scores</h3>
    ${marks.length ? marks.map(m => `<div class="card" style="padding:10px 14px;margin-bottom:6px;display:flex;justify-content:space-between">
      <span>${escapeHtml(subjectOf(m.subjectId)?.name || "")}</span>
      <span><strong>${m.total}</strong> · ${m.grade}</span>
    </div>`).join("") : `<div class="empty">No marks yet</div>`}
    ${notes.length ? `<h3 style="font-size:14px;margin:14px 0 8px">Latest nursery notes</h3>
      ${notes.map(n => `<div class="nursery-card" style="margin-bottom:8px;font-size:13px">
        <strong>${n.date}</strong> — ${escapeHtml(n.mood || "")} · ${escapeHtml(n.teacherNote || n.activity || "")}
      </div>`).join("")}` : ""}
    ` : ""}`;
  }

  function viewCBT(ctx) {
    const { attempt, questions, examId, index } = ctx;
    const exam = db.exams.find(e => e.id === examId);
    const i = index || 0;
    const q = questions[i];
    if (!q) return `<div class="empty">No questions</div>`;
    const left = Math.max(0, attempt.endsAt - now());
    const mins = Math.floor(left / 60000), secs = Math.floor((left % 60000) / 1000);
    const selected = attempt.answers[q.id];
    return `
    <div class="cbt-shell">
      <div class="cbt-header">
        <div><strong>${escapeHtml(exam?.title || "CBT")}</strong>
          <div style="font-size:12px;color:var(--muted)">Q ${i + 1} / ${questions.length}</div></div>
        <div class="timer ${left < 60000 ? "danger" : ""}" id="cbt-timer">${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}</div>
      </div>
      <div class="q-card">
        <div class="q-num">QUESTION ${i + 1}</div>
        <div class="q-text">${escapeHtml(q.text)}</div>
        ${(q.options || []).map(opt => `
          <label class="opt ${selected === opt ? "selected" : ""}">
            <input type="radio" name="ans" value="${escapeHtml(opt)}" ${selected === opt ? "checked" : ""}>
            <span>${escapeHtml(opt)}</span>
          </label>`).join("")}
        <div style="display:flex;justify-content:space-between;margin-top:16px;gap:8px">
          <button class="btn btn-secondary" id="cbt-prev" ${i === 0 ? "disabled" : ""}>Previous</button>
          <button class="btn btn-primary" id="cbt-next">${i === questions.length - 1 ? "Review & Submit" : "Next"}</button>
        </div>
      </div>
      <div class="card" style="padding:12px">
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px">
          ${questions.map((qq, qi) => `<button class="q-dot ${qi === i ? "current" : ""} ${attempt.answers[qq.id] != null ? "answered" : ""}" data-q-goto="${qi}">${qi + 1}</button>`).join("")}
        </div>
        <button class="btn btn-danger btn-block" id="cbt-submit">Submit examination</button>
      </div>
    </div>`;
  }

  /* ---- Print helpers ---- */
  function printResult(id) {
    const r = db.results.find(x => x.id === id);
    if (!r) return;
    const u = userOf(r.userId);
    const e = db.exams.find(x => x.id === r.examId);
    const school = schoolOf(r.schoolId);
    showPrint(`
    <div class="print-sheet">
      <h1>${escapeHtml(school?.name || "School")}</h1>
      <p style="text-align:center;font-size:13px">${escapeHtml(school?.address || "")}</p>
      <h2 style="text-align:center;font-size:15px;margin:12px 0">CBT RESULT SLIP</h2>
      <p><strong>Student:</strong> ${escapeHtml(u ? u.firstName + " " + u.lastName : "")}</p>
      <p><strong>Exam:</strong> ${escapeHtml(e?.title || "")}</p>
      <table>
        <tr><th>Score</th><td>${r.rawScore} / ${r.maxScore}</td></tr>
        <tr><th>Percentage</th><td>${r.percentage.toFixed(1)}%</td></tr>
        <tr><th>Grade</th><td>${r.grade}</td></tr>
        <tr><th>Correct</th><td>${r.correct}</td></tr>
        <tr><th>Wrong</th><td>${r.wrong}</td></tr>
      </table>
      <p style="margin-top:20px;font-size:11px;color:#666">${new Date().toLocaleString()}</p>
    </div>`);
  }

  function printReport(id) {
    const rc = db.reportCards.find(x => x.id === id);
    if (!rc) return;
    const u = userOf(rc.userId);
    const school = schoolOf(rc.schoolId);
    const st = db.students.find(s => s.userId === rc.userId);
    showPrint(`
    <div class="print-sheet">
      <h1>${escapeHtml(school?.name || "School")}</h1>
      <p style="text-align:center;font-size:12px">${escapeHtml(school?.address || "")}</p>
      <h2 style="text-align:center;font-size:14px;margin:10px 0">Progress Report Sheet — ${escapeHtml(rc.termName || "")}, ${escapeHtml(rc.sessionName || "")}</h2>
      <p><strong>Student:</strong> ${escapeHtml(u ? u.firstName + " " + u.lastName : "")} &nbsp;
         <strong>Class:</strong> ${escapeHtml(classOf(rc.classId)?.name || "")} &nbsp;
         <strong>Adm No:</strong> ${escapeHtml(st?.admissionNumber || "—")}</p>
      <p style="font-size:12px;text-align:center;color:#666">${rc.source === "AUTO_CBT" ? "Scores from Computer-Based Tests (CBT)" : "Continuous Assessment & Examination"}</p>
      <table>
        <thead><tr><th>Subject</th><th>CA1</th><th>CA2</th><th>Exam/CBT</th><th>Total %</th><th>Grade</th></tr></thead>
        <tbody>
          ${(rc.subjects || []).map(s => `<tr>
            <td>${escapeHtml(s.subject)}${s.examTitle ? "<br><small>" + escapeHtml(s.examTitle) + "</small>" : ""}</td>
            <td>${s.ca1}</td><td>${s.ca2}</td><td>${s.exam}</td>
            <td>${typeof s.total === "number" ? s.total.toFixed(1) : s.total}</td><td>${s.grade}</td>
          </tr>`).join("")}
          <tr><th colspan="4">Average</th><td>${rc.average?.toFixed(1)}</td><td>${rc.overallGrade}</td></tr>
        </tbody>
      </table>
      <p style="margin-top:16px"><strong>Class Teacher remark:</strong> ${escapeHtml(rc.teacherRemark || "—")}</p>
      <p><strong>Principal remark:</strong> ${escapeHtml(rc.principalRemark || "—")}</p>
      <div style="margin-top:32px;display:flex;justify-content:space-between;align-items:flex-end;gap:24px;font-size:12px;flex-wrap:wrap">
        <div style="text-align:center;min-width:140px">
          <div style="height:56px;border-bottom:1px solid #333;margin-bottom:6px"></div>
          Class Teacher<br>Signature &amp; Date
        </div>
        <div style="text-align:center;min-width:120px">
          ${school?.stamp
            ? `<img src="${school.stamp}" alt="School stamp" style="max-height:90px;max-width:120px;object-fit:contain">`
            : `<div style="height:90px;width:90px;border:2px dashed #999;border-radius:50%;margin:0 auto;display:flex;align-items:center;justify-content:center;color:#999;font-size:11px">SCHOOL<br>STAMP</div>`}
          <div style="margin-top:4px">Official Stamp</div>
        </div>
        <div style="text-align:center;min-width:140px">
          ${school?.signature
            ? `<img src="${school.signature}" alt="Principal signature" style="max-height:56px;max-width:160px;object-fit:contain;display:block;margin:0 auto 6px">`
            : `<div style="height:56px;border-bottom:1px solid #333;margin-bottom:6px"></div>`}
          Principal / Admin<br>Signature &amp; Date
        </div>
      </div>
      <p style="text-align:center;font-size:10px;color:#666;margin-top:20px">This report was generated on the Montclair CBT portal · ${new Date().toLocaleDateString()}</p>
    </div>`);
  }

  function showPrint(html) {
    const content = document.querySelector(".content");
    if (!content) return;
    content.innerHTML = html + `<div class="no-print" style="margin-top:16px;display:flex;gap:8px">
      <button class="btn btn-primary" onclick="window.print()">Print / Save as PDF</button>
      <button class="btn btn-secondary" id="close-print">Close</button>
    </div>`;
    document.getElementById("close-print")?.addEventListener("click", () => render());
  }

  /* ---- Bind ---- */
  function bind() {
    document.querySelectorAll("[data-go]").forEach(el => {
      el.onclick = e => { e.preventDefault(); go(el.getAttribute("data-go"), { role: el.getAttribute("data-role") }); };
    });
    document.querySelectorAll("[data-set-role]").forEach(el => {
      el.onclick = () => go("register", { role: el.getAttribute("data-set-role"), regPassport: ui.regPassport });
    });
    document.querySelectorAll("[data-page]").forEach(el => {
      el.onclick = e => { e.preventDefault(); ui = { ...ui, page: el.getAttribute("data-page"), cbt: null }; render(); };
    });

    async function doLogout(e) {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      try { await api.logout(); } catch (err) {}
      ui = {};
      route = "landing";
      go("landing");
      toast("Signed out", "ok");
    }
    document.getElementById("btn-logout")?.addEventListener("click", doLogout);
    document.getElementById("btn-logout-top")?.addEventListener("click", doLogout);
    document.getElementById("notif-bell")?.addEventListener("click", () => {
      ui = Object.assign({}, ui, { page: "notifications" });
      render();
    });

    const btnMenu = document.getElementById("btn-menu");
    const sidebar = document.getElementById("sidebar");
    const overlay = document.getElementById("overlay");
    if (btnMenu) {
      btnMenu.style.display = window.innerWidth <= 768 ? "inline-flex" : "none";
      btnMenu.onclick = () => { sidebar?.classList.add("open"); overlay?.classList.add("show"); };
      overlay?.addEventListener("click", () => { sidebar?.classList.remove("open"); overlay.classList.remove("show"); });
    }

    document.getElementById("btn-login")?.addEventListener("click", doLogin);
    document.getElementById("login-pass")?.addEventListener("keydown", e => { if (e.key === "Enter") doLogin(); });
    async function doLogin() {
      const btn = document.getElementById("btn-login");
      if (btn) { btn.disabled = true; btn.textContent = "Signing in…"; }
      try {
        const res = await api.login(document.getElementById("login-email")?.value, document.getElementById("login-pass")?.value);
        if (res.error) { toast(res.error, "err"); return; }
        toast("Welcome, " + (res.user?.firstName || ""), "ok");
        ui = { page: "dashboard" };
        render();
      } finally {
        if (btn) { btn.disabled = false; btn.textContent = "Sign in"; }
      }
    }

    
    document.getElementById("reg-dob")?.addEventListener("change", function () {
      const dob = this.value;
      const ageEl = document.getElementById("reg-age");
      if (!dob || !ageEl) return;
      const birth = new Date(dob);
      const today = new Date();
      let age = today.getFullYear() - birth.getFullYear();
      const m = today.getMonth() - birth.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
      ageEl.value = age > 0 && age < 100 ? age : "";
    });

    function applyPassportFile(file) {
      if (!file) return;
      if (file.type && !String(file.type).startsWith("image/")) {
        toast("Please choose an image", "err");
        return;
      }
      if (file.size > 4 * 1024 * 1024) { toast("Image too large (max 4MB)", "err"); return; }
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result;
        ui.regPassport = dataUrl;
        const prev = document.getElementById("reg-pass-preview");
        if (prev) {
          if (prev.tagName === "IMG") prev.src = dataUrl;
          else {
            const img = document.createElement("img");
            img.className = "passport-preview";
            img.id = "reg-pass-preview";
            img.src = dataUrl;
            img.alt = "Passport";
            prev.replaceWith(img);
          }
        }
        closePassSheet();
        toast("Passport photo added", "ok");
      };
      reader.onerror = () => toast("Could not read photo", "err");
      reader.readAsDataURL(file);
    }

    function openPassSheet() {
      const sheet = document.getElementById("pass-sheet");
      if (sheet) { sheet.classList.remove("hidden"); sheet.style.display = "flex"; }
    }
    function closePassSheet() {
      const sheet = document.getElementById("pass-sheet");
      if (sheet) { sheet.classList.add("hidden"); sheet.style.display = "none"; }
    }

    document.getElementById("reg-pass-wrap")?.addEventListener("click", openPassSheet);
    document.getElementById("btn-pass-camera")?.addEventListener("click", () => document.getElementById("reg-passport-camera")?.click());
    document.getElementById("btn-pass-gallery")?.addEventListener("click", () => document.getElementById("reg-passport-gallery")?.click());
    document.getElementById("btn-pass-file")?.addEventListener("click", () => document.getElementById("reg-passport-file")?.click());
    document.getElementById("sheet-camera")?.addEventListener("click", () => document.getElementById("reg-passport-camera")?.click());
    document.getElementById("sheet-gallery")?.addEventListener("click", () => document.getElementById("reg-passport-gallery")?.click());
    document.getElementById("sheet-file")?.addEventListener("click", () => document.getElementById("reg-passport-file")?.click());
    document.getElementById("sheet-cancel")?.addEventListener("click", closePassSheet);
    document.getElementById("pass-sheet")?.addEventListener("click", (e) => {
      if (e.target.id === "pass-sheet") closePassSheet();
    });

    ["reg-passport-camera", "reg-passport-gallery", "reg-passport-file"].forEach(function (id) {
      document.getElementById(id)?.addEventListener("change", function () {
        applyPassportFile(this.files && this.files[0]);
        this.value = "";
      });
    });

    document.getElementById("btn-register")?.addEventListener("click", async () => {
      if (!ui.regPassport) { toast("Please upload your passport photograph", "err"); return; }
      const role = ui.role || "STUDENT";
      const dob = document.getElementById("reg-dob")?.value || null;
      let age = document.getElementById("reg-age")?.value || null;
      if (dob && !age) {
        const birth = new Date(dob);
        const today = new Date();
        age = today.getFullYear() - birth.getFullYear();
        const m = today.getMonth() - birth.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
      }
      const btnR = document.getElementById("btn-register");
      if (btnR) { btnR.disabled = true; btnR.textContent = "Submitting…"; }
      let res;
      try {
        res = await api.registerUser({
          role,
          schoolCode: document.getElementById("reg-code")?.value,
          firstName: document.getElementById("reg-fn")?.value,
          lastName: document.getElementById("reg-ln")?.value,
          email: document.getElementById("reg-email")?.value,
          password: document.getElementById("reg-pass")?.value,
          phone: document.getElementById("reg-phone")?.value,
          passport: ui.regPassport,
          classId: document.getElementById("reg-class")?.value || null,
          dob, age: age ? parseInt(age, 10) : null,
          gender: document.getElementById("reg-gender")?.value || null,
          bloodGroup: document.getElementById("reg-blood")?.value || null,
          address: document.getElementById("reg-address")?.value || null,
          guardianName: document.getElementById("reg-guardian")?.value || null,
          guardianPhone: document.getElementById("reg-guardian-phone")?.value || null,
          designation: document.getElementById("reg-des")?.value || null,
          subjectsTaught: document.getElementById("reg-subjects")?.value || null,
          qualification: document.getElementById("reg-qualification")?.value || null,
          nextOfKin: document.getElementById("reg-nok")?.value || null
        });
      } finally {
        if (btnR) { btnR.disabled = false; btnR.textContent = "Submit for approval"; }
      }
      if (!res) return;
      if (res.error) { toast(res.error, "err"); return; }
      toast(res.message, "ok");
      ui.regPassport = null;
      setTimeout(() => go("login"), 1600);
    });

    document.getElementById("ar-next1")?.addEventListener("click", async () => {
      const schoolName = document.getElementById("ar-school")?.value.trim();
      const address = document.getElementById("ar-address")?.value.trim();
      if (!schoolName || !address) { toast("Name and address required", "err"); return; }
      ui.schoolName = schoolName; ui.address = address;
      ui.phone = document.getElementById("ar-phone")?.value;
      ui.schoolEmail = document.getElementById("ar-semail")?.value;
      const logoF = document.getElementById("ar-logo")?.files?.[0];
      if (logoF) {
        ui.logo = await new Promise((res, rej) => {
          const r = new FileReader();
          r.onload = () => res(r.result);
          r.onerror = rej;
          r.readAsDataURL(logoF);
        });
      }
      ui.step = 2;
      render();
    });
    document.getElementById("ar-back2")?.addEventListener("click", () => { ui.step = 1; render(); });
    document.getElementById("ar-submit")?.addEventListener("click", () => {
      const res = api.registerSchool({
        schoolName: ui.schoolName, address: ui.address, phone: ui.phone,
        schoolEmail: ui.schoolEmail, logo: ui.logo,
        firstName: document.getElementById("ar-fn")?.value,
        lastName: document.getElementById("ar-ln")?.value,
        email: document.getElementById("ar-email")?.value,
        password: document.getElementById("ar-pass")?.value
      });
      if (res.error) { toast(res.error, "err"); return; }
      ui = { doneCode: res.schoolCode };
      toast("School registered!", "ok");
      render();
    });

    document.querySelectorAll("[data-approve]").forEach(el => {
      el.onclick = async (e) => {
        e.stopPropagation();
        el.disabled = true;
        const r = await api.approveUser(el.getAttribute("data-approve"));
        if (r.error) toast(r.error, "err"); else { toast("Approved", "ok"); render(); }
      };
    });
    document.querySelectorAll("[data-open-user]").forEach(el => {
      el.onclick = (e) => {
        if (e.target.closest("[data-approve]")) return;
        ui = Object.assign({}, ui, { page: "users", viewUserId: el.getAttribute("data-open-user") });
        render();
      };
    });
    document.getElementById("btn-back-users")?.addEventListener("click", () => {
      ui = Object.assign({}, ui, { page: "users", viewUserId: null });
      render();
    });
    document.querySelectorAll("[data-user-filter]").forEach(el => {
      el.onclick = () => {
        ui = Object.assign({}, ui, { page: "users", userFilter: el.getAttribute("data-user-filter"), viewUserId: null });
        render();
      };
    });
    document.querySelectorAll("[data-set-class]").forEach(el => {
      // may already exist below — detail view uses same attribute
    });
    document.querySelectorAll("[data-set-class]").forEach(el => {
      el.onchange = () => { api.setStudentClass(el.getAttribute("data-set-class"), el.value); toast("Class updated", "ok"); };
    });
    document.getElementById("btn-link-parent")?.addEventListener("click", () => {
      const r = api.linkParentChild(document.getElementById("link-parent")?.value, document.getElementById("link-child")?.value);
      if (r.error) toast(r.error, "err"); else toast("Parent linked to child", "ok");
    });
    document.getElementById("user-search")?.addEventListener("input", function () {
      const q = this.value.toLowerCase().trim();
      document.querySelectorAll(".user-row").forEach(row => {
        row.style.display = !q || (row.getAttribute("data-search") || "").includes(q) ? "" : "none";
      });
    });

    document.querySelectorAll("[data-assign]").forEach(el => {
      el.onclick = () => {
        const userId = el.getAttribute("data-assign");
        const classes = db.classes.filter(c => c.schoolId === session.schoolId);
        const subjects = db.subjects.filter(s => s.schoolId === session.schoolId);
        const box = document.getElementById("assign-modal");
        if (!box) return;
        box.innerHTML = `<div class="modal-bg" id="assign-bg"><div class="modal">
          <div style="width:36px;height:4px;background:#ddd;border-radius:4px;margin:0 auto 12px"></div>
          <h3>Assign subject</h3>
          <p class="hint" style="margin-bottom:12px">Choose the class and subject this staff member will teach.</p>
          <div class="field"><label class="label">Class</label>
            <select class="select" id="as-class">${classes.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("")}</select></div>
          <div class="field"><label class="label">Subject</label>
            <select class="select" id="as-subj">${subjects.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join("")}</select></div>
          <div class="modal-actions">
            <button type="button" class="btn btn-primary btn-block" id="as-save">Save assignment</button>
            <button type="button" class="btn btn-secondary btn-block" id="as-cancel">Cancel</button>
          </div>
        </div></div>`;
        document.getElementById("as-cancel").onclick = () => { box.innerHTML = ""; };
        document.getElementById("assign-bg")?.addEventListener("click", (e) => {
          if (e.target.id === "assign-bg") box.innerHTML = "";
        });
        document.getElementById("as-save").onclick = () => {
          const r = api.assignStaff(userId, document.getElementById("as-class").value, document.getElementById("as-subj").value);
          if (r.error) toast(r.error, "err"); else { toast("Assigned", "ok"); box.innerHTML = ""; render(); }
        };
      };
    });

    /* Marks */
    document.getElementById("mark-class")?.addEventListener("change", function () {
      ui = { ...ui, page: "marks", markClass: this.value, markSubj: document.getElementById("mark-subj")?.value };
      render();
    });
    document.getElementById("mark-subj")?.addEventListener("change", function () {
      ui = { ...ui, page: "marks", markClass: document.getElementById("mark-class")?.value, markSubj: this.value };
      render();
    });
    document.getElementById("btn-approve-all-ca")?.addEventListener("click", () => {
      const r = api.approveMarks([]);
      toast("Approved " + (r.count || 0) + " CA entries", "ok");
      render();
    });

    function readImageFile(file, maxMb, cb) {
      if (!file) return;
      if (file.size > maxMb * 1024 * 1024) { toast("Image max " + maxMb + "MB", "err"); return; }
      const r = new FileReader();
      r.onload = () => cb(r.result);
      r.readAsDataURL(file);
    }
    document.getElementById("sig-file")?.addEventListener("change", function () {
      readImageFile(this.files && this.files[0], 2, (url) => {
        api.setSchoolSignature(url);
        toast("Signature saved — shows on report cards", "ok");
        render();
      });
      this.value = "";
    });
    document.getElementById("stamp-file")?.addEventListener("change", function () {
      readImageFile(this.files && this.files[0], 2, (url) => {
        api.setSchoolStamp(url);
        toast("Stamp saved — shows on report cards", "ok");
        render();
      });
      this.value = "";
    });

    document.getElementById("btn-save-marks")?.addEventListener("click", () => {
      const rows = [];
      document.querySelectorAll(".mass-input-grid tbody tr").forEach(tr => {
        rows.push({
          studentUserId: tr.getAttribute("data-stu"),
          ca1: tr.querySelector(".m-ca1")?.value,
          ca2: tr.querySelector(".m-ca2")?.value,
          exam: tr.querySelector(".m-exam")?.value
        });
      });
      api.saveMarks({
        subjectId: document.getElementById("mark-subj")?.value,
        classId: document.getElementById("mark-class")?.value,
        rows
      });
      toast(session.role === "ADMIN" ? "CA saved (approved)" : "CA submitted — waiting for admin approval", "ok");
      render();
    });

    /* Attendance */
    document.getElementById("att-class")?.addEventListener("change", function () {
      ui = { ...ui, page: "attendance", attClass: this.value, attDate: document.getElementById("att-date")?.value };
      render();
    });
    document.getElementById("att-date")?.addEventListener("change", function () {
      ui = { ...ui, page: "attendance", attClass: document.getElementById("att-class")?.value, attDate: this.value };
      render();
    });
    document.querySelectorAll(".att-toggle button").forEach(btn => {
      btn.onclick = () => {
        const row = btn.closest(".att-row");
        row.querySelectorAll("button").forEach(b => b.className = "");
        const st = btn.getAttribute("data-st");
        btn.className = st === "PRESENT" ? "on-p" : st === "ABSENT" ? "on-a" : "on-l";
        row.setAttribute("data-status", st);
      };
    });
    document.getElementById("btn-save-att")?.addEventListener("click", () => {
      const records = [];
      document.querySelectorAll(".att-row").forEach(row => {
        records.push({
          studentUserId: row.getAttribute("data-stu"),
          status: row.getAttribute("data-status") || "PRESENT"
        });
      });
      api.saveAttendance(document.getElementById("att-class")?.value, document.getElementById("att-date")?.value, records);
      toast("Attendance saved", "ok");
    });

    /* Nursery notes */
    document.querySelectorAll(".btn-save-note").forEach(btn => {
      btn.onclick = () => {
        const id = btn.getAttribute("data-stu");
        api.saveDailyNote(id, {
          meal: document.querySelector(`.n-meal[data-stu="${id}"]`)?.value,
          nap: document.querySelector(`.n-nap[data-stu="${id}"]`)?.value,
          activity: document.querySelector(`.n-act[data-stu="${id}"]`)?.value,
          mood: document.querySelector(`.n-mood[data-stu="${id}"]`)?.value,
          teacherNote: document.querySelector(`.n-note[data-stu="${id}"]`)?.value
        });
        toast("Daily note saved", "ok");
      };
    });
    document.getElementById("n-class")?.addEventListener("change", function () {
      ui = { ...ui, page: "nursery", nClass: this.value };
      render();
    });
    document.getElementById("parent-child-sel")?.addEventListener("change", function () {
      ui = { ...ui, childId: this.value };
      render();
    });

    /* Questions / exams */
    
    
    document.getElementById("gal-file")?.addEventListener("change", async function () {
      const file = this.files && this.files[0];
      if (!file) return;
      if (file.size > 4 * 1024 * 1024) { toast("Image too large (max 4MB)", "err"); return; }
      const st = document.getElementById("gal-status");
      if (st) st.textContent = "Uploading…";
      try {
        const dataUrl = await new Promise((res, rej) => {
          const r = new FileReader();
          r.onload = () => res(r.result);
          r.onerror = rej;
          r.readAsDataURL(file);
        });
        if (!db.galleryImages) db.galleryImages = [];
        db.galleryImages.unshift({
          id: uid(),
          schoolId: session.schoolId,
          src: dataUrl,
          caption: document.getElementById("gal-caption")?.value?.trim() || file.name,
          by: session.id,
          at: now()
        });
        // Notify staff & students
        db.users.filter(u => u.schoolId === session.schoolId && u.status === "ACTIVE" && (u.role === "STUDENT" || u.role === "STAFF" || u.role === "PARENT"))
          .forEach(u => notify(u.id, "New gallery photo", document.getElementById("gal-caption")?.value?.trim() || "A new photo was added to the school gallery"));
        saveDB();
        toast("Photo added to gallery", "ok");
        ui = Object.assign({}, ui, { page: "gallery" });
        render();
      } catch (e) {
        toast("Upload failed", "err");
        if (st) st.textContent = "";
      }
    });
    document.querySelectorAll("[data-del-gal]").forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const id = btn.getAttribute("data-del-gal");
        if (!confirm("Delete this photo?")) return;
        db.galleryImages = (db.galleryImages || []).filter(g => g.id !== id);
        saveDB();
        toast("Deleted", "ok");
        render();
      };
    });
    document.getElementById("btn-bcast")?.addEventListener("click", () => {
      const title = document.getElementById("bcast-title")?.value?.trim();
      const body = document.getElementById("bcast-body")?.value?.trim();
      if (!title || !body) { toast("Title and message required", "err"); return; }
      const targets = db.users.filter(u => u.schoolId === session.schoolId && u.status === "ACTIVE" && u.role !== "ADMIN");
      targets.forEach(u => notify(u.id, title, body));
      saveDB();
      toast("Sent to " + targets.length + " users", "ok");
      render();
    });

    document.querySelectorAll("[data-gallery]").forEach(img => {
      img.onclick = () => {
        const box = document.getElementById("lightbox");
        if (!box) return;
        const srcImg = img.getAttribute("data-gal-src") || img.src;
        box.className = "lightbox";
        box.innerHTML = `<img src="${srcImg}" alt=""><p style="color:#fff;text-align:center;margin-top:8px">${escapeHtml(img.title || "")}</p>`;
        box.onclick = () => { box.className = "hidden"; box.innerHTML = ""; };
      };
    });

    document.getElementById("btn-new-q")?.addEventListener("click", () => document.getElementById("q-form")?.classList.remove("hidden"));
    document.getElementById("btn-cancel-q")?.addEventListener("click", () => document.getElementById("q-form")?.classList.add("hidden"));
    document.getElementById("btn-save-q")?.addEventListener("click", () => {
      const options = (document.getElementById("q-opts")?.value || "").split("\n").map(s => s.trim()).filter(Boolean);
      const text = document.getElementById("q-text")?.value.trim();
      const correct = document.getElementById("q-correct")?.value.trim();
      if (!text || !correct || !options.length) { toast("Fill all fields", "err"); return; }
      api.createQuestion({
        text, subjectId: document.getElementById("q-subj").value,
        classId: document.getElementById("q-class").value || null,
        type: "MULTIPLE_CHOICE", options, correctAnswer: correct,
        marks: parseFloat(document.getElementById("q-marks").value) || 1
      });
      toast("Saved", "ok"); render();
    });
    document.querySelectorAll("[data-del-q]").forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        if (!confirm("Delete this question? It will stay gone until you upload again.")) return;
        const r = api.deleteQuestion(btn.getAttribute("data-del-q"));
        if (r.error) toast(r.error, "err");
        else { toast("Question deleted", "ok"); render(); }
      };
    });
    document.getElementById("btn-bulk-q")?.addEventListener("click", () => {
      const f = document.getElementById("bulk-form");
      if (f) f.classList.remove("hidden");
      ui.showBulk = true;
    });
    document.getElementById("btn-go-questions")?.addEventListener("click", () => {
      ui = { page: "questions", showBulk: true };
      render();
    });
    document.getElementById("btn-cancel-bulk")?.addEventListener("click", () => document.getElementById("bulk-form")?.classList.add("hidden"));
    document.getElementById("bulk-file")?.addEventListener("change", async function () {
      const file = this.files && this.files[0];
      if (!file) { toast("No file selected", "err"); return; }
      const name = (file.name || "").toLowerCase();
      try {
        toast("Reading file…", "info");
        let rows = [];
        if (name.endsWith(".csv") || name.endsWith(".txt")) {
          const text = await file.text();
          rows = parseCSV(text);
        } else {
          const ok = await ensureXLSX();
          if (!ok) {
            toast("Could not load Excel reader. Save your file as CSV and upload again.", "err");
            return;
          }
          const data = await file.arrayBuffer();
          const wb = XLSX.read(data, { type: "array" });
          const sheet = wb.Sheets[wb.SheetNames[0]];
          rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
        }
        if (!rows.length) {
          toast("Sheet is empty. Use headers: question, optionA, optionB, optionC, optionD, correct, marks", "err");
          return;
        }
        // Normalize header keys (trim / lower variants)
        rows = rows.map(r => {
          const o = {};
          Object.keys(r).forEach(k => {
            const key = String(k).trim();
            o[key] = r[k];
            o[key.toLowerCase()] = r[k];
          });
          return o;
        });
        const subj = document.getElementById("bulk-subj")?.value;
        const cls = document.getElementById("bulk-class")?.value || null;
        const res = await api.bulkQuestions(rows, subj, cls);
        if (res.error) { toast(res.error, "err"); return; }
        if (!res.count) {
          toast("0 questions imported. Check headers: question, optionA, optionB, optionC, optionD, correct, marks", "err");
          return;
        }
        toast("Imported " + res.count + " questions — saved", "ok");
        this.value = "";
        ui = Object.assign({}, ui, { page: "questions" });
        render();
      } catch (e) {
        console.error(e);
        toast("Could not read file: " + (e.message || "invalid file") + ". Try CSV format.", "err");
      }
    });

    document.getElementById("btn-new-exam")?.addEventListener("click", () => document.getElementById("exam-form")?.classList.remove("hidden"));
    document.getElementById("btn-cancel-exam")?.addEventListener("click", () => document.getElementById("exam-form")?.classList.add("hidden"));
    document.getElementById("btn-save-exam")?.addEventListener("click", () => {
      const qids = [...document.querySelectorAll(".ex-q:checked")].map(x => x.value);
      if (!document.getElementById("ex-title")?.value.trim() || !qids.length) { toast("Title and questions required", "err"); return; }
      api.createExam({
        title: document.getElementById("ex-title").value.trim(),
        subjectId: document.getElementById("ex-subj").value,
        classId: document.getElementById("ex-class").value,
        durationMinutes: parseInt(document.getElementById("ex-dur").value, 10) || 40,
        passMark: parseFloat(document.getElementById("ex-pass").value) || 40,
        questionIds: qids, randomizeQuestions: true, randomizeOptions: true
      });
      toast("Exam saved as draft", "ok"); render();
    });
    document.querySelectorAll("[data-publish-exam]").forEach(el => {
      el.onclick = () => { api.publishExam(el.getAttribute("data-publish-exam")); toast("Published", "ok"); render(); };
    });
    document.querySelectorAll("[data-publish-result]").forEach(el => {
      el.onclick = () => { api.publishResult(el.getAttribute("data-publish-result")); toast("Published", "ok"); render(); };
    });
    document.querySelectorAll("[data-print-result]").forEach(el => {
      el.onclick = () => printResult(el.getAttribute("data-print-result"));
    });
    document.getElementById("btn-gen-rc")?.addEventListener("click", () => {
      const sid = document.getElementById("rc-student")?.value;
      if (!sid) { toast("Select a student", "err"); return; }
      const r = api.generateReport(sid);
      if (r.error) toast(r.error, "err"); else { toast("Report card generated from CBT", "ok"); render(); }
    });
    document.getElementById("btn-gen-rc-all")?.addEventListener("click", () => {
      const classId = document.getElementById("rc-class")?.value || null;
      const r = api.generateReportsFromCBT(classId);
      if (!r.count) toast("No CBT results found to build report cards", "err");
      else toast("Generated " + r.count + " report card(s) from CBT", "ok");
      render();
    });
    document.querySelectorAll("[data-publish-rc]").forEach(el => {
      el.onclick = () => { api.publishReport(el.getAttribute("data-publish-rc")); toast("Published", "ok"); render(); };
    });
    document.querySelectorAll("[data-print-rc]").forEach(el => {
      el.onclick = () => printReport(el.getAttribute("data-print-rc"));
    });
    document.getElementById("btn-post-notice")?.addEventListener("click", () => {
      const t = document.getElementById("notice-title")?.value.trim();
      const b = document.getElementById("notice-body")?.value.trim();
      if (!t || !b) { toast("Title and message required", "err"); return; }
      api.postNotice(t, b);
      toast("Notice posted", "ok");
      render();
    });

    document.querySelectorAll("[data-start-exam]").forEach(el => {
      el.onclick = () => {
        const examId = el.getAttribute("data-start-exam");
        const exam = db.exams.find(e => e.id === examId);
        if (!confirm("Start CBT?\n\n" + (exam?.title || "") + "\nDuration: " + (exam?.durationMinutes || 40) + " minutes\nOne attempt only.")) return;
        const res = api.startAttempt(examId);
        if (res.error) { toast(res.error, "err"); return; }
        ui = { cbt: { attempt: res.attempt, questions: res.questions, examId, index: 0 } };
        render();
        startTimer();
      };
    });

    if (ui.cbt) {
      document.querySelectorAll('input[name="ans"]').forEach(inp => {
        inp.onchange = () => {
          api.saveAnswer(ui.cbt.attempt.id, ui.cbt.questions[ui.cbt.index].id, inp.value);
          ui.cbt.attempt = db.attempts.find(a => a.id === ui.cbt.attempt.id);
        };
      });
      document.getElementById("cbt-prev")?.addEventListener("click", () => {
        ui.cbt.index = Math.max(0, ui.cbt.index - 1);
        ui.cbt.attempt = db.attempts.find(a => a.id === ui.cbt.attempt.id);
        render(); startTimer();
      });
      document.getElementById("cbt-next")?.addEventListener("click", () => {
        if (ui.cbt.index >= ui.cbt.questions.length - 1) {
          if (confirm("Submit examination?")) finishCbt(false);
        } else {
          ui.cbt.index++;
          ui.cbt.attempt = db.attempts.find(a => a.id === ui.cbt.attempt.id);
          render(); startTimer();
        }
      });
      document.querySelectorAll("[data-q-goto]").forEach(el => {
        el.onclick = () => {
          ui.cbt.index = parseInt(el.getAttribute("data-q-goto"), 10);
          ui.cbt.attempt = db.attempts.find(a => a.id === ui.cbt.attempt.id);
          render(); startTimer();
        };
      });
      document.getElementById("cbt-submit")?.addEventListener("click", () => {
        if (confirm("Submit now?")) finishCbt(false);
      });
    }
  }

  function startTimer() {
    if (timerHandle) clearInterval(timerHandle);
    if (!ui.cbt) return;
    timerHandle = setInterval(() => {
      const a = db.attempts.find(x => x.id === ui.cbt.attempt.id);
      if (!a || a.status !== "IN_PROGRESS") { clearInterval(timerHandle); return; }
      const left = a.endsAt - now();
      if (left <= 0) { clearInterval(timerHandle); finishCbt(true); return; }
      const el = document.getElementById("cbt-timer");
      if (el) {
        const m = Math.floor(left / 60000), s = Math.floor((left % 60000) / 1000);
        el.textContent = String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
        el.className = "timer " + (left < 60000 ? "danger" : "");
      }
    }, 500);
  }

  function finishCbt(auto) {
    if (timerHandle) clearInterval(timerHandle);
    api.submitAttempt(ui.cbt.attempt.id, auto);
    ui = { page: "results" };
    toast(auto ? "Time up — submitted" : "Exam submitted", "ok");
    render();
  }

  async function boot() {
    db = initDB();
    restoreSession();
    const ok = await probeServer();
    if (ok) {
      console.log("Montclair server connected — shared data across devices");
      if (authToken && session) {
        try { await pullState(); } catch (e) {
          console.warn("session refresh failed", e);
          setSession(null);
        }
      }
    } else {
      console.log("Offline mode: data stays on this device only. Deploy the Node server for shared access.");
    }
    render();
  }
  boot();
  window.addEventListener("resize", () => {
    const btn = document.getElementById("btn-menu");
    if (btn) btn.style.display = window.innerWidth <= 768 ? "inline-flex" : "none";
  });
})();
